# FastAPI main application

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
import asyncio
import logging
from typing import List, Optional

from ..data.database import get_db, init_database, SessionLocal
from ..data.models import Timetable, TrainEvent, Station, Block, SOPDocument, SOPChunk, Recommendation
from ..services.ingest_service import IngestService
from ..services.events_service import EventsService
from ..services.reasoning_service import ReasoningService
from ..config import settings
from pydantic import BaseModel
from random import Random
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Railway Operations System",
    description="API for railway operations management",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
ingest_service = IngestService()
events_service = EventsService()
reasoning_service = ReasoningService()
# Delay creating the potentially heavy RAG service until it's needed so the
# API can start without ML dependencies like `sentence-transformers`.
rag_service = None  # type: Optional[object]
sim_task = None  # background simulation task
last_sim_tick: Optional[datetime] = None
last_sim_inserts: int = 0

@app.on_event("startup")
async def startup_event():
    """Initialize database on startup"""
    init_database()
    logger.info("Application started successfully")
    # Ensure there is baseline data if DB is empty
    try:
        db = SessionLocal()
        total_tt = db.query(Timetable).count()
        total_ev = db.query(TrainEvent).count()
        if total_tt == 0 and total_ev == 0:
            logger.info("Seeding baseline synthetic data (no timetables/events found)")
            _generate_synthetic(db, trains=120, severe_pct=0.2, moderate_pct=0.3, reset=True)
            db.commit()
        db.close()
    except Exception as e:
        logger.error(f"Startup seed error: {e}")

    # Auto-ingest SOP files from disk on startup (no-frontend flow)
    try:
        import os
        sop_dir = settings.sop_dir
        files = [f for f in os.listdir(sop_dir) if os.path.isfile(os.path.join(sop_dir, f))]
        if files:
            db = SessionLocal()
            from sqlalchemy import exists
            for fname in files:
                fpath = os.path.join(sop_dir, fname)
                # Skip if already present
                present = db.query(SOPDocument).filter(SOPDocument.file_path == fpath).first()
                if present:
                    continue
                try:
                    # Use filename (without extension) as title by default
                    await ingest_service.ingest_sop_from_path(fpath, title=os.path.splitext(fname)[0], db=db)
                except Exception as sop_err:
                    logger.warning(f"SOP auto-ingest skipped for {fname}: {sop_err}")
            db.close()
    except Exception as e:
        logger.error(f"Startup SOP auto-ingest error: {e}")

    # Launch background simulator to emulate real-time changes
    try:
        global sim_task
        sim_task = asyncio.create_task(_simulation_loop())
    except Exception as e:
        logger.error(f"Failed to start simulation loop: {e}")

    # Warm-initialize RAG service so LLM client is selected (especially when Gemini key is present)
    try:
        global rag_service
        if rag_service is None:
            from ..services.rag_service import RAGService
            rag_service = RAGService()
            logger.info(f"RAG service initialized with client={getattr(rag_service, 'llm_client', None)}")
    except Exception as e:
        logger.warning(f"RAG warm initialization failed: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    global sim_task
    if sim_task is not None:
        sim_task.cancel()
        try:
            await sim_task
        except Exception:
            pass

# Ingest Service Routes
@app.post("/api/ingest/timetable")
async def ingest_timetable(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload and parse timetable file"""
    try:
        result = await ingest_service.parse_timetable(file, db)
        return {"message": "Timetable ingested successfully", "records": result}
    except Exception as e:
        logger.error(f"Timetable ingest error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/ingest/topology")
async def ingest_topology(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload and parse topology file"""
    try:
        result = await ingest_service.parse_topology(file, db)
        return {"message": "Topology ingested successfully", "records": result}
    except Exception as e:
        logger.error(f"Topology ingest error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/ingest/sop")
async def ingest_sop(
    file: UploadFile = File(...),
    title: str = Form(...),
    db: Session = Depends(get_db)
):
    """Upload and parse SOP document"""
    try:
        result = await ingest_service.parse_sop(file, title, db)
        return {"message": "SOP ingested successfully", "doc_id": result}
    except Exception as e:
        logger.error(f"SOP ingest error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

# Events Service Routes
@app.post("/api/events")
async def create_event(
    event_data: dict,
    db: Session = Depends(get_db)
):
    """Create a new train event"""
    try:
        result = await events_service.create_event(event_data, db)
        return {"message": "Event created successfully", "event_id": result}
    except Exception as e:
        logger.error(f"Event creation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

# Dashboard helper route: get delayed trains
@app.get("/api/events/delayed")
async def get_delayed_trains(
    min_delay: int = 5,
    db: Session = Depends(get_db)
):
    """Get trains with delays above threshold for dashboards"""
    try:
        trains = await events_service.get_delayed_trains(db, min_delay)
        # Return both keys for backward/forward compatibility with different clients
        return {"trains": trains, "events": trains}
    except Exception as e:
        logger.error(f"Get delayed trains error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/events/{train_no}")
async def get_events(
    train_no: str,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get events for a specific train"""
    try:
        events = await events_service.get_train_events(train_no, limit, db)
        return {"events": events}
    except Exception as e:
        logger.error(f"Get events error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

    

# Debug route to inspect database configuration and counts
@app.get("/api/debug/db-stats")
async def debug_db_stats(db: Session = Depends(get_db)):
    try:
        from ..data.database import engine
        total_events = db.query(TrainEvent).count()
        delayed_ge5 = db.query(TrainEvent).filter(TrainEvent.delay_minutes >= 5).count()
        total_stations = db.query(Station).count()
        total_blocks = db.query(Block).count()
        total_timetables = db.query(Timetable).count()

        engine_url = str(engine.url)
        is_sqlite = "sqlite" in engine_url
        sqlite_db_path = engine.url.database if is_sqlite else None

        return {
            "database_url": settings.database_url,
            "engine_url": engine_url,
            "sqlite_db_path": sqlite_db_path,
            "counts": {
                "stations": total_stations,
                "blocks": total_blocks,
                "timetables": total_timetables,
                "events_total": total_events,
                "events_delayed_ge_5": delayed_ge5,
            }
        }
    except Exception as e:
        logger.error(f"Debug DB stats error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Metrics route to power dashboard without synthetic data
@app.get("/api/metrics/summary")
async def metrics_summary(db: Session = Depends(get_db)):
    """Return aggregate delay metrics based on current database content.
    Values are computed from actual TrainEvent and Timetable rows.
    """
    try:
        # Total distinct trains (prefer timetables, else events as fallback)
        total_trains = db.query(Timetable.train_no).distinct().count()
        if total_trains == 0:
            total_trains = db.query(TrainEvent.train_no).distinct().count()

        # Build a set of latest events per train (to align with dashboard table semantics)
        from sqlalchemy import and_
        subq = db.query(
            TrainEvent.train_no.label('train_no'),
            func.max(TrainEvent.created_at).label('max_created_at')
        ).group_by(TrainEvent.train_no).subquery()

        latest_q = db.query(TrainEvent).join(
            subq,
            and_(
                TrainEvent.train_no == subq.c.train_no,
                TrainEvent.created_at == subq.c.max_created_at
            )
        )

        latest_count = latest_q.count()
        # Derive metrics from latest snapshot per train
        delayed_latest = latest_q.filter(TrainEvent.delay_minutes >= 5).count()
        severe_latest = latest_q.filter(TrainEvent.delay_minutes > 30).count()
        avg_delay_latest = latest_q.filter(TrainEvent.delay_minutes >= 5).with_entities(
            func.avg(TrainEvent.delay_minutes)
        ).scalar() or 0.0

        # Keep total events as raw count (all history)
        total_events = db.query(TrainEvent).count()

        return {
            "total_trains": int(total_trains or 0),
            "total_events": int(total_events or 0),
            "delayed_trains": int(delayed_latest or 0),
            "severe_trains": int(severe_latest or 0),
            "avg_delay_minutes": float(avg_delay_latest or 0.0),
            "latest_events_sample": int(latest_count or 0)
        }
    except Exception as e:
        logger.error(f"Metrics summary error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Reasoning Service Routes
@app.post("/api/reasoning/analyze")
async def analyze_delay(
    event_id: str,
    db: Session = Depends(get_db)
):
    """Analyze delay and generate recommendations"""
    try:
        result = await reasoning_service.analyze_delay(event_id, db)
        return result
    except Exception as e:
        logger.error(f"Delay analysis error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/recommendations/{train_no}")
async def get_recommendations(
    train_no: str,
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """Get recommendations for a train"""
    try:
        recommendations = await reasoning_service.get_recommendations(train_no, limit, db)
        # Auto-generate recommendations on demand if none exist yet
        if not recommendations:
            # Find the most recent delayed event for this train
            latest_event = db.query(TrainEvent).filter(
                TrainEvent.train_no == train_no,
                TrainEvent.delay_minutes >= 5
            ).order_by(TrainEvent.created_at.desc()).first()

            if latest_event is not None:
                # Run analysis to populate recommendations
                await reasoning_service.analyze_delay(latest_event.event_id, db)
                # Fetch again
                recommendations = await reasoning_service.get_recommendations(train_no, limit, db)

        return {"recommendations": recommendations}
    except Exception as e:
        logger.error(f"Get recommendations error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

# SOP helper route: fetch SOP content by label or chunk id
@app.get("/api/sop/by-label")
async def get_sop_by_label(label: str, db: Session = Depends(get_db)):
    """Get SOP chunk text by a friendly label (e.g., 'skip_halt_procedure') or by chunk_id.
    For labels, we map to the seeded SOP001 chunk indexes.
    """
    try:
        # If a chunk_id is provided directly, fetch by id
        if label.startswith("SOP"):
            chunk = db.query(SOPChunk).filter(SOPChunk.chunk_id == label).first()
            if not chunk:
                raise HTTPException(status_code=404, detail=f"SOP chunk {label} not found")
            doc = db.query(SOPDocument).filter(SOPDocument.doc_id == chunk.doc_id).first()
            return {
                "doc_id": chunk.doc_id,
                "title": doc.title if doc else chunk.doc_id,
                "chunk_index": chunk.chunk_index,
                "text": chunk.text,
            }

        # Map friendly labels to SOP001 chunk indexes
        label_map = {
            "skip_halt_procedure": 1,
            "overtake_procedure": 2,
            "platform_change_procedure": 3,
            "priority_procedure": 4,
        }
        if label not in label_map:
            raise HTTPException(status_code=404, detail=f"Unknown SOP label: {label}")

        idx = label_map[label]
        chunk = db.query(SOPChunk).filter(SOPChunk.doc_id == "SOP001", SOPChunk.chunk_index == idx).first()
        if not chunk:
            raise HTTPException(status_code=404, detail=f"SOP section not found for label {label}")
        doc = db.query(SOPDocument).filter(SOPDocument.doc_id == "SOP001").first()
        return {
            "doc_id": "SOP001",
            "title": doc.title if doc else "SOP001",
            "chunk_index": chunk.chunk_index,
            "text": chunk.text,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get SOP by label error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# RAG Service Routes
class RAGQuery(BaseModel):
    query: str
    limit: int = 5
    mode: Optional[str] = "detailed"  # 'structured' or 'detailed'

@app.post("/api/rag/query")
async def query_sop(
    payload: RAGQuery,
    db: Session = Depends(get_db)
):
    """Query SOP documents using RAG"""
    try:
        global rag_service
        # Import and instantiate RAGService lazily on first use so the
        # server can start without the sentence-transformers dependency.
        if rag_service is None:
            from ..services.rag_service import RAGService
            rag_service = RAGService()

        result = await rag_service.query_sop(payload.query, payload.limit, db, mode=(payload.mode or "detailed"))
        return result
    except Exception as e:
        logger.error(f"RAG query error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

# Admin utilities
class SyntheticIngestRequest(BaseModel):
    trains: int = 150
    severe_pct: float = 0.25
    moderate_pct: float = 0.35
    reset: bool = True

def _generate_synthetic(db: Session, trains: int, severe_pct: float, moderate_pct: float, reset: bool) -> dict:
    """Core synthetic generation logic used by both the admin endpoint and startup seeding."""
    rng = Random(42)

    # Ensure a minimal topology exists
    stations = db.query(Station).all()
    if not stations:
        base_codes = [f"STN{i:03d}" for i in range(1, 7)]
        for code in base_codes:
            db.add(Station(code=code, name=f"Station {code}", lat=0.0, lon=0.0, station_type="intermediate"))
        db.commit()
        stations = db.query(Station).all()
    station_codes = [s.code for s in stations][:6]

    if db.query(Block).count() == 0:
        for i in range(len(station_codes) - 1):
            db.add(Block(block_id=f"SYN_BLK_{i:03d}", from_station=station_codes[i], to_station=station_codes[i+1], distance_km=10.0, max_speed=100.0, block_type="main"))
        db.commit()

    # Optional reset for generated trains
    gen_train_nos = [f"T{10000+i}" for i in range(trains)]
    if reset:
        db.query(TrainEvent).filter(TrainEvent.train_no.in_(gen_train_nos)).delete(synchronize_session=False)
        db.query(Timetable).filter(Timetable.train_no.in_(gen_train_nos)).delete(synchronize_session=False)
        db.commit()

    base_date = datetime.now().replace(hour=6, minute=0, second=0, microsecond=0)

    created_events = 0
    created_tt = 0
    for idx in range(trains):
        train_no = gen_train_nos[idx]
        depart = base_date + timedelta(minutes=rng.randint(0, 180))

        # Timetable: 6 stops
        for j, code in enumerate(station_codes):
            arr = depart + timedelta(minutes=20*j)
            dep = arr + timedelta(minutes=2)
            db.add(Timetable(train_no=train_no, station_code=code, sched_arrival=arr, sched_departure=dep, stop_order=j+1))
            created_tt += 1

        # Delay category selection
        r = rng.random()
        if r < severe_pct:
            delay_base = rng.randint(31, 60)
        elif r < severe_pct + moderate_pct:
            delay_base = rng.randint(10, 30)
        else:
            delay_base = rng.randint(0, 9)

        for j, code in enumerate(station_codes):
            sched = depart + timedelta(minutes=20*j)
            variability = rng.randint(-2, 6)
            event_delay = max(0, delay_base + variability - (j*rng.randint(0, 3)))
            status = 'on_time'
            if event_delay > 30:
                status = 'very_delayed'
            elif event_delay >= 5:
                status = 'delayed'
            db.add(TrainEvent(
                event_id=f"{train_no}_{code}_{j}",
                train_no=train_no,
                station_code=code,
                sched_arrival=sched,
                actual_arrival=sched + timedelta(minutes=event_delay),
                status=status,
                delay_minutes=event_delay,
            ))
            created_events += 1

    return {
        "trains": trains,
        "timetable_entries": created_tt,
        "events": created_events
    }

@app.post("/api/admin/ingest/synthetic")
async def ingest_synthetic_data(payload: SyntheticIngestRequest, db: Session = Depends(get_db)):
    """Generate synthetic trains, timetables, and events with varied delay profiles for richer dashboards."""
    try:
        result = _generate_synthetic(db, payload.trains, payload.severe_pct, payload.moderate_pct, payload.reset)
        db.commit()
        return {"message": "Synthetic data generated", **result}
    except Exception as e:
        db.rollback()
        logger.error(f"Synthetic ingest error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

async def _simulation_loop():
    """Background loop that simulates new delay events periodically to emulate real-time data changes."""
    rng = Random()
    global last_sim_tick, last_sim_inserts
    while True:
        try:
            db = SessionLocal()
            # Pick some train numbers from existing timetables or events
            train_nos = [t[0] for t in db.query(Timetable.train_no).distinct().limit(50).all()]
            if not train_nos:
                train_nos = [t[0] for t in db.query(TrainEvent.train_no).distinct().limit(50).all()]

            if train_nos:
                # Create 3-6 new events each tick with small variability
                inserts = 0
                for _ in range(rng.randint(3, 6)):
                    tn = rng.choice(train_nos)
                    code = f"STN{rng.randint(1,6):03d}"
                    base = rng.randint(0, 35)
                    jitter = rng.randint(-3, 8)
                    delay = max(0, base + jitter)
                    status = 'on_time'
                    if delay > 30:
                        status = 'very_delayed'
                    elif delay >= 5:
                        status = 'delayed'
                    now = datetime.now()
                    db.add(TrainEvent(
                        event_id=f"SIM_{tn}_{code}_{int(now.timestamp())}_{rng.randint(0,999)}",
                        train_no=tn,
                        station_code=code,
                        sched_arrival=now,
                        actual_arrival=now + timedelta(minutes=delay),
                        status=status,
                        delay_minutes=delay,
                    ))
                    inserts += 1
                db.commit()
                last_sim_inserts = inserts
                last_sim_tick = datetime.utcnow()
            db.close()
        except Exception as e:
            try:
                db.rollback()
                db.close()
            except Exception:
                pass
            logger.error(f"Simulation loop error: {e}")
        # Wait before next tick
        await asyncio.sleep(15)

# Debug: simulator status
@app.get("/api/debug/sim-status")
async def sim_status():
    running = sim_task is not None and not sim_task.done()
    return {
        "running": running,
        "last_tick": last_sim_tick.isoformat() if last_sim_tick else None,
        "last_inserts": last_sim_inserts,
    }

# Admin: re-scan and ingest SOPs from sop_dir
@app.post("/api/admin/ingest/sop-from-dir")
async def ingest_sops_from_dir(db: Session = Depends(get_db)):
    import os
    try:
        sop_dir = settings.sop_dir
        files = [f for f in os.listdir(sop_dir) if os.path.isfile(os.path.join(sop_dir, f))]
        ingested = []
        skipped = []
        for fname in files:
            fpath = os.path.join(sop_dir, fname)
            present = db.query(SOPDocument).filter(SOPDocument.file_path == fpath).first()
            if present:
                skipped.append(fname)
                continue
            try:
                await ingest_service.ingest_sop_from_path(fpath, title=os.path.splitext(fname)[0], db=db)
                ingested.append(fname)
            except Exception as sop_err:
                logger.warning(f"SOP ingest failed for {fname}: {sop_err}")
        return {"ingested": ingested, "skipped": skipped}
    except Exception as e:
        logger.error(f"SOP dir ingest error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "version": "1.0.0"}

# Debug: LLM client status
@app.get("/api/debug/llm-status")
async def llm_status():
    try:
        # Ensure RAG service is initialized before reporting status
        global rag_service
        if rag_service is None:
            try:
                from ..services.rag_service import RAGService
                rag_service = RAGService()
            except Exception:
                pass
        client = getattr(rag_service, 'llm_client', None) if rag_service is not None else None
        return {
            "configured_model_type": getattr(settings, 'llm_model_type', None),
            "gemini_key_present": bool(getattr(settings, 'gemini_api_key', None)),
            "client_selected": client or "uninitialized",
            "gemini_model": getattr(settings, 'gemini_model', None),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Debug: LLM probe (verifies Gemini key works by making a tiny request)
@app.get("/api/debug/llm-probe")
async def llm_probe():
    try:
        global rag_service
        if rag_service is None:
            from ..services.rag_service import RAGService
            rag_service = RAGService()
        client = getattr(rag_service, 'llm_client', None)
        result = {
            "client_selected": client or "uninitialized",
            "gemini_key_present": bool(getattr(settings, 'gemini_api_key', None)),
            "gemini_ok": None,
            "error": None,
        }
        if client == 'gemini':
            try:
                import requests
                body = {
                    "contents": [
                        {"parts": [{"text": "Return OK"}]}
                    ],
                    "generationConfig": {"maxOutputTokens": 1}
                }
                # Try multiple models and API versions similar to the RAG service
                model_candidates = [
                    getattr(settings, 'gemini_model', 'gemini-1.5-flash'),
                    'gemini-1.5-flash-latest',
                    'gemini-1.5-flash-001',
                    'gemini-1.5-pro',
                    'gemini-1.0-pro',
                    'gemini-pro',
                ]
                urls = []
                for model in model_candidates:
                    urls.append(f"https://generativelanguage.googleapis.com/v1/models/{model}:generateContent?key={getattr(settings, 'gemini_api_key')}")
                    urls.append(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={getattr(settings, 'gemini_api_key')}")
                last_err = None
                for u in urls:
                    try:
                        resp = requests.post(u, json=body, timeout=8)
                        resp.raise_for_status()
                        result["gemini_ok"] = True
                        last_err = None
                        break
                    except Exception as e:
                        last_err = e
                        continue
                if last_err is not None:
                    raise last_err
            except Exception as e:
                result["gemini_ok"] = False
                result["error"] = str(e)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Debug: List available Gemini models for this API key
@app.get("/api/debug/llm-list-models")
async def llm_list_models():
    try:
        from ..services.rag_service import RAGService
        svc = RAGService()
        if svc.llm_client != 'gemini':
            return {"client_selected": svc.llm_client or "uninitialized", "models": []}
        import requests
        key = getattr(settings, 'gemini_api_key', None)
        if not key:
            raise HTTPException(status_code=400, detail="Gemini API key not configured")
        urls = [
            f"https://generativelanguage.googleapis.com/v1/models?key={key}",
            f"https://generativelanguage.googleapis.com/v1beta/models?key={key}",
        ]
        results = []
        errors = []
        for u in urls:
            try:
                r = requests.get(u, timeout=8)
                r.raise_for_status()
                data = r.json()
                for m in data.get('models', []):
                    name = m.get('name') or m.get('displayName')
                    if name:
                        results.append(name)
            except Exception as e:
                errors.append({"url": u, "error": str(e)})
        # de-dupe
        seen = set(); ordered = []
        for n in results:
            if n not in seen:
                seen.add(n); ordered.append(n)
        return {"client_selected": svc.llm_client, "models": ordered, "errors": errors}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.api_host, port=settings.api_port)
