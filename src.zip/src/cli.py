# CLI tool for Railway Operations System

import click
import asyncio
import logging
from pathlib import Path
import pandas as pd
from datetime import datetime, timedelta
import uuid
import random

from .data.database import init_database, get_db_session
from .data.models import Timetable, TrainEvent, Station, Block, SOPDocument, SOPChunk
from .config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@click.group()
def cli():
    """Railway Operations System CLI"""
    pass

@cli.command()
def setup_db():
    """Initialize database with tables"""
    try:
        init_database()
        click.echo("SUCCESS: Database initialized successfully!")
    except Exception as e:
        click.echo(f"ERROR: Database initialization failed: {e}")
        raise click.Abort()

@cli.command()
def ingest_real_csv():
    """Ingest the real timetable CSV file with 186k records"""
    try:
        click.echo("INFO: Ingesting real timetable CSV...")
        
        import asyncio
        from .services.ingest_service import IngestService
        ingest_service = IngestService()
        
        async def run_ingest():
            with get_db_session() as db:
                csv_path = "train_rout..csv"
                if not os.path.exists(csv_path):
                    click.echo(f"ERROR: CSV file not found: {csv_path}")
                    return
                
                records_added = await ingest_service.parse_real_timetable_csv(csv_path, db)
                click.echo(f"SUCCESS: Ingested {records_added} records from real CSV!")
        
        asyncio.run(run_ingest())
            
    except Exception as e:
        click.echo(f"ERROR: Real CSV ingestion failed: {e}")
        raise click.Abort()

@cli.command()
def ingest_sample():
    """Ingest sample data for testing"""
    try:
        click.echo("INFO: Creating sample data...")
        
        with get_db_session() as db:
            # Clean existing sample data to make this command idempotent
            try:
                sample_station_codes = ["STN001", "STN002", "STN003", "STN004", "STN005"]
                sample_block_ids = ["BLK001", "BLK002", "BLK003", "BLK004", "BLK005"]
                sample_trains = ["12345", "67890", "11111", "22222", "33333"]

                # Delete dependent records first (child -> parent order)
                db.query(SOPChunk).filter(SOPChunk.doc_id == "SOP001").delete(synchronize_session=False)
                db.query(SOPDocument).filter(SOPDocument.doc_id == "SOP001").delete(synchronize_session=False)
                db.query(TrainEvent).filter(TrainEvent.train_no.in_(sample_trains)).delete(synchronize_session=False)
                db.query(Timetable).filter(Timetable.train_no.in_(sample_trains)).delete(synchronize_session=False)
                db.query(Block).filter(Block.block_id.in_(sample_block_ids)).delete(synchronize_session=False)
                db.query(Station).filter(Station.code.in_(sample_station_codes)).delete(synchronize_session=False)
                db.commit()
                click.echo("INFO: Removed existing sample data (if any)")
            except Exception as cleanup_err:
                db.rollback()
                click.echo(f"WARN: Cleanup step encountered an issue (continuing): {cleanup_err}")
            # Create sample stations
            stations = [
                Station(code="STN001", name="Central Station", lat=40.7128, lon=-74.0060, station_type="junction"),
                Station(code="STN002", name="North Terminal", lat=40.7589, lon=-73.9851, station_type="terminal"),
                Station(code="STN003", name="South Junction", lat=40.6892, lon=-74.0445, station_type="junction"),
                Station(code="STN004", name="East Platform", lat=40.7505, lon=-73.9934, station_type="intermediate"),
                Station(code="STN005", name="West Station", lat=40.7614, lon=-73.9776, station_type="intermediate"),
            ]
            
            for station in stations:
                db.add(station)
            # Ensure stations are persisted before inserting blocks which
            # reference stations via foreign keys. Commit here to avoid
            # foreign key constraint violations when inserting blocks.
            db.commit()
            
            # Create sample blocks
            blocks = [
                Block(block_id="BLK001", from_station="STN001", to_station="STN002", distance_km=15.5, max_speed=120, block_type="main"),
                Block(block_id="BLK002", from_station="STN001", to_station="STN003", distance_km=12.3, max_speed=100, block_type="main"),
                Block(block_id="BLK003", from_station="STN002", to_station="STN004", distance_km=8.7, max_speed=80, block_type="loop"),
                Block(block_id="BLK004", from_station="STN003", to_station="STN005", distance_km=10.2, max_speed=90, block_type="main"),
                Block(block_id="BLK005", from_station="STN004", to_station="STN005", distance_km=6.8, max_speed=70, block_type="siding"),
            ]
            
            for block in blocks:
                db.add(block)
            # Commit blocks after inserting them so subsequent inserts that
            # depend on them (timetables/events) can proceed reliably.
            db.commit()
            
            # Create sample timetable
            base_time = datetime.now().replace(hour=6, minute=0, second=0, microsecond=0)
            timetable_entries = []
            
            trains = ["12345", "67890", "11111", "22222", "33333"]
            stations_list = ["STN001", "STN002", "STN003", "STN004", "STN005"]
            
            for train_no in trains:
                current_time = base_time
                for i, station_code in enumerate(stations_list):
                    arrival_time = current_time
                    departure_time = current_time + timedelta(minutes=2)
                    
                    timetable_entries.append(Timetable(
                        train_no=train_no,
                        station_code=station_code,
                        sched_arrival=arrival_time,
                        sched_departure=departure_time,
                        stop_order=i + 1
                    ))
                    
                    current_time = departure_time + timedelta(minutes=15)  # 15 min between stations
            
            for entry in timetable_entries:
                db.add(entry)
            
            # Create sample events (some with delays)
            events = []
            for train_no in trains:
                for i, station_code in enumerate(stations_list):
                    sched_time = base_time + timedelta(minutes=i * 17)  # 17 min intervals
                    actual_time = sched_time
                    
                    # Add some delays
                    if train_no == "12345" and station_code in ["STN002", "STN003"]:
                        actual_time += timedelta(minutes=15)  # 15 min delay
                    elif train_no == "67890" and station_code == "STN004":
                        actual_time += timedelta(minutes=8)   # 8 min delay
                    
                    delay_minutes = int((actual_time - sched_time).total_seconds() / 60)
                    status = "on_time" if delay_minutes <= 0 else "delayed" if delay_minutes <= 15 else "very_delayed"
                    
                    events.append(TrainEvent(
                        event_id=f"{train_no}_{station_code}_{i}",
                        train_no=train_no,
                        station_code=station_code,
                        sched_arrival=sched_time,
                        actual_arrival=actual_time,
                        status=status,
                        delay_minutes=delay_minutes
                    ))
            
            for event in events:
                db.add(event)
            
            # Create sample SOP documents
            sop_doc = SOPDocument(
                doc_id="SOP001",
                title="Emergency Procedures Manual",
                file_path="data/sops/emergency_procedures.txt",
                file_type="txt"
            )
            db.add(sop_doc)
            
            # Create sample SOP chunks
            sop_chunks = [
                SOPChunk(
                    chunk_id="SOP001_chunk_0",
                    doc_id="SOP001",
                    text="In case of train delay exceeding 30 minutes, operators must immediately notify control center and implement recovery procedures. Priority should be given to passenger trains over freight trains.",
                    chunk_index=0
                ),
                SOPChunk(
                    chunk_id="SOP001_chunk_1",
                    doc_id="SOP001",
                    text="Skip halt procedure: Trains may skip intermediate stations if delay exceeds 15 minutes and the station is not a junction or terminal. This must be approved by control center.",
                    chunk_index=1
                ),
                SOPChunk(
                    chunk_id="SOP001_chunk_2",
                    doc_id="SOP001",
                    text="Overtake procedure: Faster trains may overtake slower trains on loop lines if delay exceeds 20 minutes. Ensure proper signaling and clearance before executing overtake.",
                    chunk_index=2
                ),
                SOPChunk(
                    chunk_id="SOP001_chunk_3",
                    doc_id="SOP001",
                    text="Platform change procedure: In case of platform congestion, trains may be redirected to alternative platforms. Notify passengers and ensure proper signage is updated.",
                    chunk_index=3
                ),
                SOPChunk(
                    chunk_id="SOP001_chunk_4",
                    doc_id="SOP001",
                    text="Priority assignment: During peak hours (7-9 AM, 5-7 PM), passenger trains have priority over freight trains. Emergency services always have highest priority.",
                    chunk_index=4
                )
            ]
            
            for chunk in sop_chunks:
                db.add(chunk)
            
            db.commit()
            click.echo("SUCCESS: Sample data ingested successfully!")
            click.echo(f"   - {len(stations)} stations")
            click.echo(f"   - {len(blocks)} blocks")
            click.echo(f"   - {len(timetable_entries)} timetable entries")
            click.echo(f"   - {len(events)} train events")
            click.echo(f"   - 1 SOP document with {len(sop_chunks)} chunks")
            
    except Exception as e:
        click.echo(f"ERROR: Sample data ingestion failed: {e}")
        raise click.Abort()

@cli.command()
def start_api():
    """Start the FastAPI server"""
    import uvicorn
    click.echo("INFO: Starting FastAPI server...")
    # Disable reload to avoid Windows file watcher errors on inaccessible folders (e.g., .venv_wsl)
    # If you want reload during development, run uvicorn manually:
    #   uvicorn src.api.main:app --host 0.0.0.0 --port <port> --reload --reload-exclude ".venv_wsl/*"
    click.echo(f"INFO: API will listen on http://{('localhost' if settings.api_host in {'0.0.0.0','127.0.0.1'} else settings.api_host)}:{settings.api_port}")
    uvicorn.run("src.api.main:app", host=settings.api_host, port=settings.api_port, reload=False)

@cli.command()
def start_ui():
    """Start the Streamlit UI"""
    import subprocess
    import os
    click.echo("INFO: Starting Streamlit UI...")
    # Ensure UI talks to the same API host/port as the backend
    host = "localhost" if settings.api_host in {"0.0.0.0", "127.0.0.1"} else settings.api_host
    api_url = f"http://{host}:{settings.api_port}"
    env = os.environ.copy()
    env["API_BASE_URL"] = api_url
    click.echo(f"INFO: UI will use API_BASE_URL={api_url}")
    subprocess.run(["streamlit", "run", "src/ui/app.py"], env=env)

@cli.command()
@click.option('--train-no', required=True, help='Train number to analyze')
def analyze_delay(train_no):
    """Analyze delay for a specific train"""
    try:
        with get_db_session() as db:
            events = db.query(TrainEvent).filter(TrainEvent.train_no == train_no).all()
            
            if not events:
                click.echo(f"ERROR: No events found for train {train_no}")
                return
            
            click.echo(f"INFO: Delay analysis for train {train_no}:")
            
            total_delay = sum(event.delay_minutes for event in events)
            avg_delay = total_delay / len(events)
            max_delay = max(event.delay_minutes for event in events)
            
            click.echo(f"   Total delay: {total_delay} minutes")
            click.echo(f"   Average delay: {avg_delay:.1f} minutes")
            click.echo(f"   Maximum delay: {max_delay} minutes")
            
            delayed_events = [e for e in events if e.delay_minutes > 0]
            if delayed_events:
                click.echo(f"   Delayed stations: {', '.join([e.station_code for e in delayed_events])}")
            
    except Exception as e:
        click.echo(f"ERROR: Analysis failed: {e}")

if __name__ == "__main__":
    cli()

@cli.command()
@click.option('--trains', default=100, show_default=True, help='Number of trains to generate')
@click.option('--severe-pct', default=0.2, show_default=True, help='Fraction of trains with severe delays (>30 min)')
@click.option('--moderate-pct', default=0.3, show_default=True, help='Fraction of trains with moderate delays (10-30 min)')
@click.option('--reset/--no-reset', default=False, show_default=True, help='Reset existing synthetic data for generated trains')
def ingest_synthetic(trains: int, severe_pct: float, moderate_pct: float, reset: bool):
    """Generate synthetic timetable and events with a distribution of delays for richer scenarios."""
    try:
        click.echo(f"INFO: Generating synthetic data for {trains} trains...")
        rng = random.Random(42)

        with get_db_session() as db:
            # Base stations/topology (reuse sample or create if missing)
            stations = db.query(Station).all()
            if not stations:
                click.echo("INFO: No stations found, creating a 6-station ring topology.")
                base_codes = [f"STN{i:03d}" for i in range(1, 7)]
                for code in base_codes:
                    db.add(Station(code=code, name=f"Station {code}", lat=0.0, lon=0.0, station_type="intermediate"))
                db.commit()
                stations = db.query(Station).all()

            station_codes = [s.code for s in stations]
            if db.query(Block).count() == 0:
                click.echo("INFO: Creating default blocks between stations")
                for i in range(len(station_codes) - 1):
                    db.add(Block(block_id=f"SYN_BLK_{i:03d}", from_station=station_codes[i], to_station=station_codes[i+1], distance_km=10.0, max_speed=100.0, block_type="main"))
                db.commit()

            # Optionally reset synthetic trains
            gen_train_nos = [f"T{10000+i}" for i in range(trains)]
            if reset:
                click.echo("INFO: Resetting existing synthetic trains...")
                db.query(TrainEvent).filter(TrainEvent.train_no.in_(gen_train_nos)).delete(synchronize_session=False)
                db.query(Timetable).filter(Timetable.train_no.in_(gen_train_nos)).delete(synchronize_session=False)
                db.commit()

            base_date = datetime.now().replace(hour=6, minute=0, second=0, microsecond=0)

            for idx in range(trains):
                train_no = gen_train_nos[idx]
                # Build a simple 6-stop timetable
                depart = base_date + timedelta(minutes=rng.randint(0, 120))
                tt_entries = []
                for j, code in enumerate(station_codes[:6]):
                    arr = depart + timedelta(minutes=20*j)
                    dep = arr + timedelta(minutes=2)
                    tt_entries.append(Timetable(train_no=train_no, station_code=code, sched_arrival=arr, sched_departure=dep, stop_order=j+1))
                for e in tt_entries:
                    db.add(e)

                # Assign delay category
                r = rng.random()
                if r < severe_pct:
                    delay_base = rng.randint(31, 60)
                elif r < severe_pct + moderate_pct:
                    delay_base = rng.randint(10, 30)
                else:
                    delay_base = rng.randint(0, 9)

                # Create events with some variability
                for j, code in enumerate(station_codes[:6]):
                    sched = depart + timedelta(minutes=20*j)
                    # Add randomness; severe more likely to persist
                    variability = rng.randint(-2, 5)
                    event_delay = max(0, delay_base + variability - (j*rng.randint(0, 3)))
                    status = 'on_time'
                    if event_delay > 30:
                        status = 'very_delayed'
                    elif event_delay >= 5:
                        status = 'delayed'
                    
                    db.add(TrainEvent(
                        event_id=f"{train_no}_{code}_{j}",
                        train_no=train_no,
                        station_code=code,
                        sched_arrival=sched,
                        actual_arrival=sched + timedelta(minutes=event_delay),
                        status=status,
                        delay_minutes=event_delay,
                    ))
            db.commit()
            click.echo("SUCCESS: Synthetic data generated.")
    except Exception as e:
        click.echo(f"ERROR: Synthetic data generation failed: {e}")
        raise click.Abort()
