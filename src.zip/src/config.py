# Configuration settings for the Railway Operations System

import os
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Database settings
    database_url: str = "postgresql://postgres:password@localhost:5432/irailops"
    neo4j_url: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password"
    
    # API settings
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    debug: bool = True
    
    # File storage
    upload_dir: str = "data/uploads"
    sop_dir: str = "data/sops"
    
    # ML settings
    model_dir: str = "models"
    
    # LLM Settings
    llm_model_type: str = "ollama"  # ollama, gemini, huggingface, template
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "llama2"  # or mistral, codellama, etc.
    huggingface_model: str = "microsoft/DialoGPT-medium"
    # Gemini (Google) settings
    gemini_api_key: Optional[str] = None
    gemini_model: str = "gemini-1.5-flash"
    
    # Vector store
    vector_store_type: str = "pgvector"  # or "qdrant"
    qdrant_url: str = "http://localhost:6333"

    # SOP chunking
    sop_chunk_words: int = 900           # words per chunk (approx)
    sop_chunk_overlap_words: int = 150   # overlap words between chunks
    
    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"  # Ignore extra fields

# Global settings instance
settings = Settings()

# Ensure directories exist
Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
Path(settings.sop_dir).mkdir(parents=True, exist_ok=True)
Path(settings.model_dir).mkdir(parents=True, exist_ok=True)