# Database models and schema

from sqlalchemy import Column, Integer, String, DateTime, Float, Text, Boolean, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
import uuid
from datetime import datetime

Base = declarative_base()

class Timetable(Base):
    __tablename__ = "timetables"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    train_no = Column(String(20), nullable=False, index=True)
    station_code = Column(String(10), nullable=False, index=True)
    sched_arrival = Column(DateTime)
    sched_departure = Column(DateTime)
    stop_order = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

class TrainEvent(Base):
    __tablename__ = "train_events"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id = Column(String(50), unique=True, nullable=False, index=True)
    train_no = Column(String(20), nullable=False, index=True)
    station_code = Column(String(10), nullable=False, index=True)
    sched_arrival = Column(DateTime)
    actual_arrival = Column(DateTime)
    sched_departure = Column(DateTime)
    actual_departure = Column(DateTime)
    status = Column(String(20))  # on_time, delayed, cancelled, etc.
    delay_minutes = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class Station(Base):
    __tablename__ = "stations"
    
    code = Column(String(10), primary_key=True)
    name = Column(String(100), nullable=False)
    lat = Column(Float)
    lon = Column(Float)
    station_type = Column(String(20))  # junction, terminal, intermediate
    created_at = Column(DateTime, default=datetime.utcnow)

class Block(Base):
    __tablename__ = "blocks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    block_id = Column(String(20), unique=True, nullable=False, index=True)
    from_station = Column(String(10), ForeignKey('stations.code'), nullable=False)
    to_station = Column(String(10), ForeignKey('stations.code'), nullable=False)
    distance_km = Column(Float)
    max_speed = Column(Float)
    block_type = Column(String(20))  # main, loop, siding
    created_at = Column(DateTime, default=datetime.utcnow)

class SOPDocument(Base):
    __tablename__ = "sop_documents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    doc_id = Column(String(50), unique=True, nullable=False, index=True)
    title = Column(String(200), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_type = Column(String(10))  # pdf, docx, txt
    uploaded_at = Column(DateTime, default=datetime.utcnow)

class SOPChunk(Base):
    __tablename__ = "sop_chunks"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    chunk_id = Column(String(50), unique=True, nullable=False, index=True)
    doc_id = Column(String(50), ForeignKey('sop_documents.doc_id'), nullable=False)
    text = Column(Text, nullable=False)
    chunk_index = Column(Integer)
    embedding = Column(JSON)  # For pgvector storage
    created_at = Column(DateTime, default=datetime.utcnow)

class Recommendation(Base):
    __tablename__ = "recommendations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    train_no = Column(String(20), nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    move_type = Column(String(50), nullable=False)  # skip_halt, overtake, prioritize, etc.
    score = Column(Float, nullable=False)
    explanation = Column(Text, nullable=False)
    sop_refs = Column(JSON)  # List of SOP chunk IDs
    status = Column(String(20), default="pending")  # pending, applied, rejected
    created_at = Column(DateTime, default=datetime.utcnow)

class DelayAnalysis(Base):
    __tablename__ = "delay_analysis"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    train_no = Column(String(20), nullable=False, index=True)
    station_code = Column(String(10), nullable=False)
    event_id = Column(String(50), ForeignKey('train_events.event_id'), nullable=False)
    delay_cause = Column(String(100))  # weather, mechanical, congestion, etc.
    confidence = Column(Float)
    features = Column(JSON)  # ML features used for prediction
    created_at = Column(DateTime, default=datetime.utcnow)

class QueryLog(Base):
    __tablename__ = "query_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    query_text = Column(Text, nullable=False)
    response_text = Column(Text)
    cited_chunks = Column(JSON)  # List of chunk IDs
    user_id = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
