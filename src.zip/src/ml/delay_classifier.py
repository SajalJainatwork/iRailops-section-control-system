# Delay Classifier - ML model for delay cause prediction

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
import os

from ..config import settings

logger = logging.getLogger(__name__)

class DelayClassifier:
    """ML classifier for predicting delay causes"""
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names = []
        self.cause_labels = [
            'weather', 'mechanical', 'congestion', 'signal_failure', 
            'passenger_delay', 'freight_conflict', 'maintenance', 'other'
        ]
        self.model_path = os.path.join(settings.model_dir, 'delay_classifier.pkl')
        self._load_or_create_model()
    
    def _load_or_create_model(self):
        """Load existing model or create new one"""
        try:
            if os.path.exists(self.model_path):
                self.model = joblib.load(self.model_path)
                logger.info("Loaded existing delay classifier model")
            else:
                self._create_new_model()
                logger.info("Created new delay classifier model")
        except Exception as e:
            logger.error(f"Model loading error: {e}")
            self._create_new_model()
    
    def _create_new_model(self):
        """Create a new Random Forest classifier"""
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            class_weight='balanced'
        )
        
        # Train with synthetic data for MVP
        self._train_with_synthetic_data()
    
    def _train_with_synthetic_data(self):
        """Train model with synthetic data for MVP"""
        # Generate synthetic training data
        np.random.seed(42)
        n_samples = 1000
        
        # Features: delay_minutes, hour_of_day, day_of_week, station_type, weather_score, etc.
        features = np.random.randn(n_samples, 8)
        features[:, 0] = np.random.exponential(10, n_samples)  # delay_minutes
        features[:, 1] = np.random.randint(0, 24, n_samples)   # hour_of_day
        features[:, 2] = np.random.randint(0, 7, n_samples)   # day_of_week
        features[:, 3] = np.random.randint(0, 3, n_samples)    # station_type
        features[:, 4] = np.random.rand(n_samples)              # weather_score
        features[:, 5] = np.random.rand(n_samples)              # congestion_score
        features[:, 6] = np.random.rand(n_samples)              # maintenance_score
        features[:, 7] = np.random.rand(n_samples)              # passenger_load
        
        # Generate labels based on simple rules
        labels = []
        for i in range(n_samples):
            delay_minutes = features[i, 0]
            weather_score = features[i, 4]
            congestion_score = features[i, 5]
            
            if weather_score > 0.7:
                labels.append('weather')
            elif congestion_score > 0.6:
                labels.append('congestion')
            elif delay_minutes > 30:
                labels.append('mechanical')
            else:
                labels.append('other')
        
        # Train the model
        self.model.fit(features, labels)
        
        # Save the model
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        joblib.dump(self.model, self.model_path)
        
        self.feature_names = [
            'delay_minutes', 'hour_of_day', 'day_of_week', 'station_type',
            'weather_score', 'congestion_score', 'maintenance_score', 'passenger_load'
        ]
    
    def predict_delay_cause(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Predict delay cause from context"""
        try:
            # Extract features from context
            features = self._extract_features(context)
            
            # Make prediction
            prediction_proba = self.model.predict_proba([features])[0]
            predicted_class = self.model.classes_[np.argmax(prediction_proba)]
            confidence = np.max(prediction_proba)
            
            return {
                'cause': predicted_class,
                'confidence': float(confidence),
                'features': dict(zip(self.feature_names, features)),
                'all_probabilities': dict(zip(self.model.classes_, prediction_proba))
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {
                'cause': 'other',
                'confidence': 0.5,
                'features': {},
                'all_probabilities': {}
            }
    
    def _extract_features(self, context: Dict[str, Any]) -> List[float]:
        """Extract features from context for prediction"""
        event = context.get('event')
        recent_events = context.get('recent_events', [])
        
        # Basic features
        delay_minutes = event.delay_minutes if event else 0
        hour_of_day = event.created_at.hour if event else 12
        day_of_week = event.created_at.weekday() if event else 0
        
        # Station type (simplified)
        station_type = 1  # Default to intermediate
        
        # Weather score (simplified - would come from weather API)
        weather_score = np.random.rand()
        
        # Congestion score based on recent events
        congestion_score = min(len(recent_events) / 10.0, 1.0)
        
        # Maintenance score (simplified)
        maintenance_score = np.random.rand() * 0.3
        
        # Passenger load (simplified)
        passenger_load = np.random.rand()
        
        return [
            delay_minutes, hour_of_day, day_of_week, station_type,
            weather_score, congestion_score, maintenance_score, passenger_load
        ]
    
    def retrain_model(self, training_data: List[Dict[str, Any]]):
        """Retrain model with new data"""
        try:
            # Extract features and labels from training data
            features = []
            labels = []
            
            for data_point in training_data:
                features.append(self._extract_features(data_point['context']))
                labels.append(data_point['cause'])
            
            # Retrain model
            self.model.fit(features, labels)
            
            # Save updated model
            joblib.dump(self.model, self.model_path)
            
            logger.info(f"Model retrained with {len(training_data)} samples")
            
        except Exception as e:
            logger.error(f"Model retraining error: {e}")
            raise
