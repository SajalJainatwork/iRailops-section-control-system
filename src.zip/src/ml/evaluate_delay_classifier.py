from __future__ import annotations

import json
import os
import argparse
from dataclasses import asdict, dataclass
from typing import Dict, Any, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
)

from .delay_classifier import DelayClassifier
from ..config import settings


@dataclass
class Metrics:
    accuracy: float
    precision_macro: float
    recall_macro: float
    f1_macro: float
    precision_weighted: float
    recall_weighted: float
    f1_weighted: float


def make_synthetic_dataset(n: int, seed: int = 42) -> Tuple[np.ndarray, np.ndarray]:
    """Replicates the synthetic generation used in DelayClassifier._train_with_synthetic_data."""
    rng = np.random.RandomState(seed)
    features = rng.randn(n, 8)
    features[:, 0] = rng.exponential(10, n)   # delay_minutes
    features[:, 1] = rng.randint(0, 24, n)    # hour_of_day
    features[:, 2] = rng.randint(0, 7, n)     # day_of_week
    features[:, 3] = rng.randint(0, 3, n)     # station_type
    features[:, 4] = rng.rand(n)              # weather_score
    features[:, 5] = rng.rand(n)              # congestion_score
    features[:, 6] = rng.rand(n)              # maintenance_score
    features[:, 7] = rng.rand(n)              # passenger_load

    labels = []
    for i in range(n):
        delay_minutes = features[i, 0]
        weather_score = features[i, 4]
        congestion_score = features[i, 5]
        if weather_score > 0.7:
            labels.append('weather')
        elif congestion_score > 0.6:
            labels.append('congestion')
        elif delay_minutes > 30:
            labels.append('mechanical')
        else:
            labels.append('other')

    return features, np.array(labels)


def evaluate(n: int, seed: int, save_json: bool = True) -> Dict[str, Any]:
    clf = DelayClassifier()  # loads existing model or trains synthetic

    X_test, y_true = make_synthetic_dataset(n, seed)
    y_pred = clf.model.predict(X_test)

    acc = accuracy_score(y_true, y_pred)
    p_macro, r_macro, f_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, average='macro', zero_division=0
    )
    p_w, r_w, f_w, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted', zero_division=0
    )

    report = classification_report(y_true, y_pred, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=clf.model.classes_).tolist()

    result = {
        'n_samples': n,
        'seed': seed,
        'classes': list(map(str, clf.model.classes_)),
        'metrics': asdict(Metrics(
            accuracy=acc,
            precision_macro=p_macro,
            recall_macro=r_macro,
            f1_macro=f_macro,
            precision_weighted=p_w,
            recall_weighted=r_w,
            f1_weighted=f_w,
        )),
        'classification_report': report,
        'confusion_matrix': cm,
    }

    if save_json:
        out_path = os.path.join(settings.model_dir, 'delay_classifier_metrics.json')
        os.makedirs(settings.model_dir, exist_ok=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2)
        print(f"Saved metrics to {out_path}")

    print('\n=== DelayClassifier Metrics ===')
    print(json.dumps(result['metrics'], indent=2))
    print('\nClassification Report:\n', report)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=2000, help='Number of synthetic test samples')
    parser.add_argument('--seed', type=int, default=123, help='Random seed')
    parser.add_argument('--no-save', action='store_true', help='Do not write metrics JSON file')
    args = parser.parse_args()
    evaluate(args.n, args.seed, save_json=not args.no_save)
