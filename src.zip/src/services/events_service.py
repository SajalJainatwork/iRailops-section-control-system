# Events Service - handles live train events

import logging
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime, timedelta
import uuid

from ..data.models import TrainEvent, Timetable, DelayAnalysis
from ..ml.delay_classifier import DelayClassifier

logger = logging.getLogger(__name__)

class EventsService:
    """Service for handling live train events and delay analysis"""
    
    def __init__(self):
        self.delay_classifier = DelayClassifier()
    
    async def create_event(self, event_data: Dict[str, Any], db: Session) -> str:
        """Create a new train event"""
        try:
            # Generate event ID if not provided
            event_id = event_data.get('event_id', str(uuid.uuid4()))
            
            # Calculate delay if times are provided
            delay_minutes = 0
            if 'actual_arrival' in event_data and 'sched_arrival' in event_data:
                sched_time = datetime.fromisoformat(event_data['sched_arrival'].replace('Z', '+00:00'))
                actual_time = datetime.fromisoformat(event_data['actual_arrival'].replace('Z', '+00:00'))
                delay_minutes = int((actual_time - sched_time).total_seconds() / 60)
            
            # Determine status
            status = self._determine_status(delay_minutes)
            
            # Create event
            event = TrainEvent(
                event_id=event_id,
                train_no=event_data['train_no'],
                station_code=event_data['station_code'],
                sched_arrival=datetime.fromisoformat(event_data['sched_arrival'].replace('Z', '+00:00')) if 'sched_arrival' in event_data else None,
                actual_arrival=datetime.fromisoformat(event_data['actual_arrival'].replace('Z', '+00:00')) if 'actual_arrival' in event_data else None,
                sched_departure=datetime.fromisoformat(event_data['sched_departure'].replace('Z', '+00:00')) if 'sched_departure' in event_data else None,
                actual_departure=datetime.fromisoformat(event_data['actual_departure'].replace('Z', '+00:00')) if 'actual_departure' in event_data else None,
                status=status,
                delay_minutes=delay_minutes
            )
            
            db.add(event)
            db.commit()
            
            logger.info(f"Created event {event_id} for train {event_data['train_no']}")
            return event_id
            
        except Exception as e:
            db.rollback()
            logger.error(f"Event creation error: {e}")
            raise
    
    async def get_train_events(self, train_no: str, limit: int, db: Session) -> List[Dict[str, Any]]:
        """Get recent events for a specific train"""
        try:
            events = db.query(TrainEvent).filter(
                TrainEvent.train_no == train_no
            ).order_by(desc(TrainEvent.created_at)).limit(limit).all()
            
            return [
                {
                    "event_id": event.event_id,
                    "train_no": event.train_no,
                    "station_code": event.station_code,
                    "sched_arrival": event.sched_arrival.isoformat() if event.sched_arrival else None,
                    "actual_arrival": event.actual_arrival.isoformat() if event.actual_arrival else None,
                    "sched_departure": event.sched_departure.isoformat() if event.sched_departure else None,
                    "actual_departure": event.actual_departure.isoformat() if event.actual_departure else None,
                    "status": event.status,
                    "delay_minutes": event.delay_minutes,
                    "created_at": event.created_at.isoformat()
                }
                for event in events
            ]
            
        except Exception as e:
            logger.error(f"Get events error: {e}")
            raise
    
    async def get_delayed_trains(self, db: Session, min_delay: int = 5) -> List[Dict[str, Any]]:
        """Get trains with delays above threshold"""
        try:
            events = db.query(TrainEvent).filter(
                TrainEvent.delay_minutes >= min_delay,
                TrainEvent.status.in_(['delayed', 'very_delayed'])
            ).order_by(desc(TrainEvent.delay_minutes)).all()
            
            return [
                {
                    "train_no": event.train_no,
                    "station_code": event.station_code,
                    "delay_minutes": event.delay_minutes,
                    "status": event.status,
                    "created_at": event.created_at.isoformat()
                }
                for event in events
            ]
            
        except Exception as e:
            logger.error(f"Get delayed trains error: {e}")
            raise
    
    async def analyze_delay_cause(self, event_id: str, db: Session) -> Dict[str, Any]:
        """Analyze delay cause using ML classifier"""
        try:
            event = db.query(TrainEvent).filter(TrainEvent.event_id == event_id).first()
            if not event:
                raise ValueError(f"Event {event_id} not found")
            
            # Get context for analysis
            context = await self._get_event_context(event, db)
            
            # Run classifier
            prediction = self.delay_classifier.predict_delay_cause(context)
            
            # Store analysis
            analysis = DelayAnalysis(
                train_no=event.train_no,
                station_code=event.station_code,
                event_id=event_id,
                delay_cause=prediction['cause'],
                confidence=prediction['confidence'],
                features=prediction['features']
            )
            db.add(analysis)
            db.commit()
            
            return prediction
            
        except Exception as e:
            db.rollback()
            logger.error(f"Delay analysis error: {e}")
            raise
    
    async def _get_event_context(self, event: TrainEvent, db: Session) -> Dict[str, Any]:
        """Get context information for delay analysis"""
        # Get recent events for the same train
        recent_events = db.query(TrainEvent).filter(
            TrainEvent.train_no == event.train_no,
            TrainEvent.created_at <= event.created_at
        ).order_by(desc(TrainEvent.created_at)).limit(5).all()
        
        # Get timetable information
        timetable = db.query(Timetable).filter(
            Timetable.train_no == event.train_no,
            Timetable.station_code == event.station_code
        ).first()
        
        return {
            "event": event,
            "recent_events": recent_events,
            "timetable": timetable,
            "delay_minutes": event.delay_minutes,
            "station_code": event.station_code
        }
    
    def _determine_status(self, delay_minutes: int) -> str:
        """Determine train status based on delay"""
        if delay_minutes <= 0:
            return "on_time"
        elif delay_minutes < 5:
            return "slightly_delayed"
        elif delay_minutes <= 30:
            return "delayed"
        else:
            return "very_delayed"
