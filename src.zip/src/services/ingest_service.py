# Ingest Service - handles file parsing and data ingestion

import pandas as pd
import logging
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from datetime import datetime
import uuid
import os

from ..data.models import Timetable, Station, Block, SOPDocument, SOPChunk
from ..config import settings

logger = logging.getLogger(__name__)

class IngestService:
    """Service for ingesting timetable, topology, and SOP files"""
    
    def __init__(self):
        self.upload_dir = settings.upload_dir
        self.sop_dir = settings.sop_dir
    
    async def parse_timetable(self, file: Any, db: Session) -> int:
        """Parse timetable CSV/Excel file and store in database"""
        try:
            # Save uploaded file
            file_path = os.path.join(self.upload_dir, file.filename)
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            # Parse file based on extension
            if file.filename.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file.filename.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file_path)
            else:
                raise ValueError("Unsupported file format")
            
            # Map CSV columns to our database schema
            column_mapping = {
                'Train No': 'train_no',
                'Station Code': 'station_code', 
                'Station Name': 'station_name',
                'Arrival time': 'sched_arrival',
                'Departure Time': 'sched_departure',
                'SEQ': 'stop_order',
                'Distance': 'distance'
            }
            
            # Rename columns to match our schema
            df = df.rename(columns=column_mapping)
            
            # Convert time columns to datetime
            df['sched_arrival'] = pd.to_datetime(df['sched_arrival'], format='%H:%M:%S', errors='coerce')
            df['sched_departure'] = pd.to_datetime(df['sched_departure'], format='%H:%M:%S', errors='coerce')
            
            # Handle '0:00:00' as None (terminal stations)
            df['sched_arrival'] = df['sched_arrival'].where(df['sched_arrival'].dt.time != pd.Timestamp('00:00:00').time())
            df['sched_departure'] = df['sched_departure'].where(df['sched_departure'].dt.time != pd.Timestamp('00:00:00').time())
            
            # Insert records
            records_added = 0
            for _, row in df.iterrows():
                timetable = Timetable(
                    train_no=str(row['train_no']),
                    station_code=str(row['station_code']),
                    sched_arrival=row['sched_arrival'],
                    sched_departure=row['sched_departure'],
                    stop_order=int(row['stop_order'])
                )
                db.add(timetable)
                records_added += 1
            
            db.commit()
            logger.info(f"Successfully ingested {records_added} timetable records")
            return records_added
        except Exception as e:
            try:
                db.rollback()
            except Exception:
                pass
            logger.error(f"Timetable parsing error: {e}")
            raise
            
    async def parse_real_timetable_csv(self, csv_path: str, db: Session) -> int:
        """Parse the real timetable CSV file with 186k records"""
        try:
            logger.info(f"Parsing real timetable CSV: {csv_path}")
            
            # Read CSV in chunks to handle large file
            chunk_size = 10000
            total_records = 0
            
            for chunk_df in pd.read_csv(csv_path, chunksize=chunk_size):
                # Map CSV columns to our database schema
                column_mapping = {
                    'Train No': 'train_no',
                    'Station Code': 'station_code', 
                    'Station Name': 'station_name',
                    'Arrival time': 'sched_arrival',
                    'Departure Time': 'sched_departure',
                    'SEQ': 'stop_order',
                    'Distance': 'distance'
                }
                
                # Rename columns to match our schema
                chunk_df = chunk_df.rename(columns=column_mapping)
                
                # Convert time columns to datetime
                chunk_df['sched_arrival'] = pd.to_datetime(chunk_df['sched_arrival'], format='%H:%M:%S', errors='coerce')
                chunk_df['sched_departure'] = pd.to_datetime(chunk_df['sched_departure'], format='%H:%M:%S', errors='coerce')
                
                # Handle '0:00:00' as None (terminal stations)
                chunk_df['sched_arrival'] = chunk_df['sched_arrival'].where(chunk_df['sched_arrival'].dt.time != pd.Timestamp('00:00:00').time())
                chunk_df['sched_departure'] = chunk_df['sched_departure'].where(chunk_df['sched_departure'].dt.time != pd.Timestamp('00:00:00').time())
                
                # Insert records for this chunk
                for _, row in chunk_df.iterrows():
                    timetable = Timetable(
                        train_no=str(row['train_no']),
                        station_code=str(row['station_code']),
                        sched_arrival=row['sched_arrival'],
                        sched_departure=row['sched_departure'],
                        stop_order=int(row['stop_order'])
                    )
                    db.add(timetable)
                    total_records += 1
                
                # Commit chunk
                db.commit()
                logger.info(f"Processed {total_records} records so far...")
            
            logger.info(f"Successfully ingested {total_records} timetable records from real CSV")
            return total_records
            
        except Exception as e:
            db.rollback()
            logger.error(f"Real timetable parsing error: {e}")
            raise
    
    async def parse_topology(self, file: Any, db: Session) -> int:
        """Parse topology CSV file and store stations and blocks"""
        try:
            # Save uploaded file
            file_path = os.path.join(self.upload_dir, file.filename)
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            # Parse file
            df = pd.read_csv(file_path)
            
            # Parse stations if present
            stations_added = 0
            if 'stations' in df.columns or all(col in df.columns for col in ['code', 'name']):
                stations_df = df[['code', 'name']].drop_duplicates()
                for _, row in stations_df.iterrows():
                    station = Station(
                        code=str(row['code']),
                        name=str(row['name']),
                        lat=row.get('lat'),
                        lon=row.get('lon'),
                        station_type=row.get('station_type', 'intermediate')
                    )
                    db.add(station)
                    stations_added += 1
            
            # Parse blocks if present
            blocks_added = 0
            if all(col in df.columns for col in ['block_id', 'from_station', 'to_station']):
                blocks_df = df[['block_id', 'from_station', 'to_station']].drop_duplicates()
                for _, row in blocks_df.iterrows():
                    block = Block(
                        block_id=str(row['block_id']),
                        from_station=str(row['from_station']),
                        to_station=str(row['to_station']),
                        distance_km=row.get('distance_km'),
                        max_speed=row.get('max_speed'),
                        block_type=row.get('block_type', 'main')
                    )
                    db.add(block)
                    blocks_added += 1
            
            db.commit()
            logger.info(f"Successfully ingested {stations_added} stations and {blocks_added} blocks")
            return stations_added + blocks_added
            
        except Exception as e:
            db.rollback()
            logger.error(f"Topology parsing error: {e}")
            raise
    
    async def parse_sop(self, file: Any, title: str, db: Session) -> str:
        """Parse SOP document and store chunks"""
        try:
            # Generate document ID
            doc_id = str(uuid.uuid4())
            
            # Save uploaded file
            file_path = os.path.join(self.sop_dir, f"{doc_id}_{file.filename}")
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            # Create SOP document record
            sop_doc = SOPDocument(
                doc_id=doc_id,
                title=title,
                file_path=file_path,
                file_type=file.filename.split('.')[-1].lower()
            )
            db.add(sop_doc)
            
            # Extract text and create chunks
            text_content = await self._extract_text_from_file(file_path)
            chunks = self._create_text_chunks(
                text_content,
                chunk_size=getattr(settings, 'sop_chunk_words', 900),
                overlap=getattr(settings, 'sop_chunk_overlap_words', 150)
            )
            
            # Store chunks
            for i, chunk_text in enumerate(chunks):
                chunk = SOPChunk(
                    chunk_id=f"{doc_id}_chunk_{i}",
                    doc_id=doc_id,
                    text=chunk_text,
                    chunk_index=i
                )
                db.add(chunk)
            
            db.commit()
            logger.info(f"Successfully ingested SOP document with {len(chunks)} chunks")
            return doc_id
            
        except Exception as e:
            db.rollback()
            logger.error(f"SOP parsing error: {e}")
            raise

    async def ingest_sop_from_path(self, file_path: str, title: str, db: Session) -> str:
        """Ingest an SOP document that already exists on disk (no frontend upload)."""
        try:
            # Generate a doc ID (stable based on filename to avoid duplicates)
            filename = os.path.basename(file_path)
            doc_id = filename.split('.')[0]

            # If this exact file was already ingested, skip
            existing = db.query(SOPDocument).filter(SOPDocument.file_path == file_path).first()
            if existing:
                logger.info(f"SOP file already ingested: {file_path}")
                return existing.doc_id

            # Create SOP document record
            sop_doc = SOPDocument(
                doc_id=doc_id,
                title=title or doc_id,
                file_path=file_path,
                file_type=filename.split('.')[-1].lower()
            )
            db.add(sop_doc)

            # Extract text and create chunks
            text_content = await self._extract_text_from_file(file_path)
            chunks = self._create_text_chunks(
                text_content,
                chunk_size=getattr(settings, 'sop_chunk_words', 900),
                overlap=getattr(settings, 'sop_chunk_overlap_words', 150)
            )

            for i, chunk_text in enumerate(chunks):
                chunk = SOPChunk(
                    chunk_id=f"{doc_id}_chunk_{i}",
                    doc_id=doc_id,
                    text=chunk_text,
                    chunk_index=i
                )
                db.add(chunk)

            db.commit()
            logger.info(f"Ingested SOP from path with {len(chunks)} chunks: {file_path}")
            return doc_id
        except Exception as e:
            db.rollback()
            logger.error(f"SOP ingest from path error: {e}")
            raise
    
    async def _extract_text_from_file(self, file_path: str) -> str:
        """Extract text from various file formats (txt, pdf)."""
        file_ext = file_path.split('.')[-1].lower()

        if file_ext == 'txt':
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        elif file_ext == 'pdf':
            try:
                # Lazy import via importlib to avoid static import errors when package isn't installed yet
                import importlib
                pypdf = importlib.import_module('pypdf')
                reader = pypdf.PdfReader(file_path)
                pages_text = []
                for page in reader.pages:
                    try:
                        text = page.extract_text() or ""
                    except Exception:
                        text = ""
                    pages_text.append(text)
                raw = "\n\n".join(pages_text).strip()
                # Normalize PDF text: fix hyphenation and whitespace
                import re
                text_content = re.sub(r"-\s*\n", "", raw)  # join hyphenated line breaks
                text_content = re.sub(r"\n+", "\n", text_content)
                text_content = re.sub(r"\s+", " ", text_content)
                return text_content.strip() or ""
            except Exception as e:
                logger.warning(f"PDF extraction failed for {file_path}: {e}")
                return ""
        else:
            # Unsupported right now (docx, etc.)
            logger.warning(f"Unsupported SOP file type for extraction: {file_ext}")
            return ""
    
    def _create_text_chunks(self, text: str, chunk_size: int = 900, overlap: int = 150) -> List[str]:
        """Split text into overlapping word chunks for better context preservation."""
        words = text.split()
        if chunk_size <= 0:
            chunk_size = 900
        if overlap < 0:
            overlap = 0
        stride = max(1, chunk_size - overlap)
        chunks: List[str] = []
        for i in range(0, len(words), stride):
            chunk_words = words[i:i + chunk_size]
            if not chunk_words:
                break
            chunks.append(' '.join(chunk_words))
            if i + chunk_size >= len(words):
                break
        return chunks
