# RAG Service - SOP-based Q&A using LLMs (Gemini/Ollama) with semantic or keyword search

import logging
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import text
import json
import requests

from ..data.models import SOPChunk, SOPDocument, QueryLog
from ..config import settings

logger = logging.getLogger(__name__)

class RAGService:
    """Service for SOP-based Q&A using LLMs (Gemini preferred if configured)."""
    
    def __init__(self):
        self.llm_client: Optional[str] = None  # 'gemini', 'ollama', or None
        self.embedding_model = None
        self.model_type = getattr(settings, 'llm_model_type', 'ollama')
        self.gemini_api_key = getattr(settings, 'gemini_api_key', None)
        self.gemini_model = getattr(settings, 'gemini_model', 'gemini-1.5-flash')

        # Initialize embedding model lazily (optional)
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore
            self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
            logger.info("Embedding model loaded successfully")
        except Exception as e:
            logger.warning(f"Could not load embedding model, falling back to keyword search: {e}")

        # Initialize LLM client preference: Gemini if key present, else Ollama if available, else template
        self._initialize_llm_client()

    def _gemini_model_candidates(self) -> List[str]:
        """Return a list of Gemini model ids to try, starting from configured one.
        Helps when accounts expose slightly different model aliases.
        """
        configured = getattr(self, 'gemini_model', 'gemini-1.5-flash')
        candidates = [
            configured,
            'gemini-1.5-flash-latest',
            'gemini-1.5-flash-001',
            'gemini-1.5-pro',
            'gemini-1.0-pro',
            'gemini-pro',
        ]
        # de-duplicate while preserving order
        seen = set()
        ordered: List[str] = []
        for m in candidates:
            if m and m not in seen:
                seen.add(m)
                ordered.append(m)
        return ordered
    
    def _initialize_llm_client(self):
        """Initialize LLM client based on configuration"""
        # Prefer Gemini if API key is present or llm_model_type=='gemini'
        if self.gemini_api_key or self.model_type == 'gemini':
            if not self.gemini_api_key:
                logger.warning("llm_model_type is 'gemini' but GEMINI API key is missing; falling back")
            else:
                self.llm_client = 'gemini'
                logger.info("Gemini client configured")
                return

        # Else, try Ollama if requested/available
        if self.model_type == 'ollama':
            try:
                response = requests.get(getattr(settings, 'ollama_url', 'http://localhost:11434') + '/api/tags', timeout=3)
                if response.status_code == 200:
                    self.llm_client = 'ollama'
                    logger.info("Ollama client initialized")
                    return
            except Exception:
                pass
            logger.warning("Ollama not available; using template fallback")
            self.llm_client = None
    
    async def query_sop(self, query: str, limit: int, db: Session, mode: str = "detailed") -> Dict[str, Any]:
        """Query SOP documents using RAG with open-source models"""
        try:
            # Use semantic search if embedding model is available
            if self.embedding_model:
                relevant_chunks = await self._search_chunks_semantic(query, limit, db)
            else:
                relevant_chunks = await self._search_chunks_keyword(query, limit, db)
            
            # Enforce topic focus to filter out off-topic chunks (e.g., avoid overtaking for priority queries)
            topic = self._infer_topic(query.lower())
            focused_chunks = self._enforce_topic_focus(relevant_chunks, topic, limit=max(8, min(20, limit)))

            # Generate response using LLM / template
            response = await self._generate_response(query, focused_chunks, mode=mode)
            
            # Log the query
            query_log = QueryLog(
                query_text=query,
                response_text=response['answer'],
                cited_chunks=[chunk['chunk_id'] for chunk in focused_chunks]
            )
            db.add(query_log)
            db.commit()
            
            result: Dict[str, Any] = {
                "query": query,
                "answer": response['answer'],
                "cited_chunks": focused_chunks,
                "confidence": response.get('confidence', 0.8),
                "model_used": (self.llm_client or "template"),
                "mode": mode
            }
            if 'structured' in response:
                result['structured'] = response['structured']
            return result
            
        except Exception as e:
            db.rollback()
            logger.error(f"RAG query error: {e}")
            raise
    
    async def _search_chunks_semantic(self, query: str, limit: int, db: Session) -> List[Dict[str, Any]]:
        """Search SOP chunks using semantic similarity"""
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode([query])[0]
            
            # Get all chunks
            chunks = db.query(SOPChunk).all()
            
            # Calculate similarities
            chunk_similarities = []
            for chunk in chunks:
                chunk_embedding = self.embedding_model.encode([chunk.text])[0]
                similarity = self._cosine_similarity(query_embedding, chunk_embedding)
                chunk_similarities.append((chunk, similarity))
            
            # Re-rank with topic awareness if applicable
            topic = self._infer_topic(query.lower())
            if topic:
                def rerank(item):
                    ch, sim = item
                    bonus = self._topic_weight(ch.text.lower(), topic)
                    return sim + 0.02 * bonus  # small topic-aware nudge
                chunk_similarities.sort(key=rerank, reverse=True)
            else:
                chunk_similarities.sort(key=lambda x: x[1], reverse=True)
            
            return [
                {
                    "chunk_id": chunk.chunk_id,
                    "doc_id": chunk.doc_id,
                    "text": chunk.text,
                    "chunk_index": chunk.chunk_index,
                    "similarity": similarity
                }
                for chunk, similarity in chunk_similarities[:limit]
            ]
            
        except Exception as e:
            logger.error(f"Semantic search error: {e}")
            return await self._search_chunks_keyword(query, limit, db)
    
    async def _search_chunks_keyword(self, query: str, limit: int, db: Session) -> List[Dict[str, Any]]:
        """Search SOP chunks using simple keyword ranking (fallback).
        Scores chunks by number of matched unique query words (case-insensitive), then by proximity.
        """
        try:
            q_lower = query.lower()
            words = [w for w in q_lower.replace('?', ' ').replace(',', ' ').split() if len(w) > 2]

            # Infer topic from query to boost relevant sections
            topic = self._infer_topic(q_lower)

            chunks_db = db.query(SOPChunk).all()

            def score_text(text: str) -> float:
                t = text.lower()
                base = sum(1 for w in set(words) if w in t)
                # Phrase boosts
                if 'peak hour' in q_lower or 'peak hours' in q_lower:
                    if 'peak hour' in t or 'peak hours' in t:
                        base += 3
                if 'priority' in q_lower or 'prioritize' in q_lower:
                    if 'priority' in t or 'prioritize' in t or 'precedence' in t:
                        base += 3
                # Topic boost/penalty
                base += self._topic_weight(t, topic)
                return float(base)

            ranked = []
            for ch in chunks_db:
                s = score_text(ch.text)
                if s > 0:
                    ranked.append((s, ch))

            # If topic is inferred, strongly prioritize topically relevant chunks
            ranked.sort(key=lambda x: (x[0], - (x[1].chunk_index or 0)), reverse=True)
            top = [ch for _, ch in ranked[:limit]]

            return [
                {
                    "chunk_id": ch.chunk_id,
                    "doc_id": ch.doc_id,
                    "text": ch.text,
                    "chunk_index": ch.chunk_index
                }
                for ch in top
            ]
        except Exception as e:
            logger.error(f"Keyword search error: {e}")
            return []

    def _get_topic_keywords(self) -> Dict[str, List[str]]:
        """Central map of topic -> keywords used across retrieval and filtering."""
        return {
            'overtake': ['overtake', 'overtaking', 'crossing loop', 'loop overtake', 'section overtake', 'station overtake', 'loop'],
            'skip_halt': ['skip halt', 'skip station', 'non-stop', 'omit halt', 'pass through', 'skip intermediate', 'omit stop'],
            'platform_change': ['platform change', 'replatform', 'change platform', 'alternate platform', 'platform re-assignment'],
            'prioritize': ['priority', 'prioritize', 'precedence', 'peak hour', 'peak hours', 'passenger trains', 'freight trains'],
        }

    def _enforce_topic_focus(self, chunks: List[Dict[str, Any]], topic: Optional[str], limit: int) -> List[Dict[str, Any]]:
        """Filter and modestly re-rank chunks to keep only those aligned with the inferred topic.
        If no topic or no matches, return original chunks (truncated to limit).
        """
        if not chunks:
            return []
        if not topic:
            return chunks[:limit]
        kws = self._get_topic_keywords().get(topic, [])
        if not kws:
            return chunks[:limit]
        scored: List[tuple] = []
        for ch in chunks:
            t = (ch.get('text') or '').lower()
            hits = sum(1 for k in kws if k in t)
            if hits > 0:
                sim = float(ch.get('similarity', 0.0)) if isinstance(ch.get('similarity', None), (int, float)) else 0.0
                scored.append((hits, sim, ch))
        if not scored:
            return chunks[:limit]
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return [c for _, _, c in scored[:limit]]

    def _infer_topic(self, q_lower: str) -> Optional[str]:
        """Heuristically infer the SOP topic from the query."""
        topic_map = {
            'overtake': ['overtake', 'overtaking', 'crossing loop', 'loop overtake'],
            'skip_halt': ['skip halt', 'skip station', 'non-stop', 'omit halt', 'pass through'],
            'platform_change': ['platform change', 'replatform', 'change platform'],
            'prioritize': ['priority', 'prioritize', 'precedence', 'peak hour', 'peak hours'],
        }
        for t, keys in topic_map.items():
            if any(k in q_lower for k in keys):
                return t
        return None

    def _topic_weight(self, text_lower: str, topic: Optional[str]) -> float:
        """Compute a small weight to boost texts matching the inferred topic and penalize off-topic ones."""
        if not topic:
            return 0.0
        keywords = self._get_topic_keywords()
        others = set(k for k in keywords.keys() if k != topic)
        weight = 0.0
        # Boost for topic keywords
        for kw in keywords.get(topic, []):
            if kw in text_lower:
                weight += 2.0
        # Penalize strong off-topic signals
        for ot in others:
            if ot == 'overtake' and any(kw in text_lower for kw in keywords['overtake']):
                weight -= 1.5
            if ot == 'platform_change' and any(kw in text_lower for kw in keywords['platform_change']):
                weight -= 1.0
            if ot == 'skip_halt' and any(kw in text_lower for kw in keywords['skip_halt']):
                weight -= 1.0
        return weight
    
    async def _generate_response(self, query: str, chunks: List[Dict[str, Any]], mode: str = "detailed") -> Dict[str, Any]:
        """Generate response using open-source LLM"""
        if not chunks:
            return {
                "answer": "I couldn't find relevant information in the SOP documents for your query.",
                "confidence": 0.0
            }
        
        if self.llm_client == 'gemini':
            if mode == "structured":
                return await self._generate_gemini_response(query, chunks)
            else:
                return await self._generate_gemini_freeform_response(query, chunks)
        elif self.llm_client == 'ollama':
            if mode == "structured":
                return await self._generate_ollama_response(query, chunks)
            else:
                return await self._generate_ollama_freeform_response(query, chunks)
        else:
            # No external LLM available; choose template based on mode
            if mode == "structured":
                return await self._generate_template_response(query, chunks)
            return await self._generate_template_freeform_response(query, chunks)

    async def _generate_gemini_freeform_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a comprehensive technical answer using Gemini without strict JSON schema."""
        try:
            if not self.gemini_api_key:
                raise RuntimeError("Gemini API key not configured")

            context = "\n\n".join([f"[Section {i+1}]\n{chunk['text']}\n(Chunk: {chunk['chunk_id']})" for i, chunk in enumerate(chunks)])
            system_instruction = (
                "You are a senior railway operations expert. Write comprehensive, technically detailed answers strictly based on the provided SOP context. "
                "Focus strictly on the user's question and ignore unrelated procedures not asked. "
                "Include purpose, conditions/thresholds, step-by-step actions, required approvals/coordination, passenger/station communications, edge cases/exceptions, and post-actions. "
                "Use clear headings and bullet/numbered lists where appropriate. Cite sections inline as [SOP:CHUNK_ID] when referencing specific rules."
            )

            def _try_gemini(url: str):
                return requests.post(url, json=body, timeout=45)

            body = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [
                            {"text": system_instruction},
                            {"text": f"User Question: {query}"},
                            {"text": f"SOP Context:\n{context}"},
                            {"text": "Answer in well-formatted Markdown."}
                        ]
                    }
                ],
                "generationConfig": {
                    "temperature": 0.3,
                    "topP": 0.9,
                    "topK": 40,
                    "maxOutputTokens": 3072
                }
            }
            # Try multiple models and API versions for compatibility across accounts
            urls = []
            for model in self._gemini_model_candidates():
                urls.append(f"https://generativelanguage.googleapis.com/v1/models/{model}:generateContent?key={self.gemini_api_key}")
                urls.append(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={self.gemini_api_key}")
            last_err = None
            data = None
            for u in urls:
                try:
                    resp = _try_gemini(u)
                    resp.raise_for_status()
                    data = resp.json()
                    break
                except Exception as e:
                    last_err = e
                    continue
            if data is None and last_err is not None:
                raise last_err
            text = ""
            try:
                candidates = data.get('candidates', [])
                if candidates:
                    # Concatenate all parts' text for the first candidate
                    parts = candidates[0].get('content', {}).get('parts', [])
                    collected: list[str] = []
                    for p in parts:
                        t = p.get('text', '')
                        if t:
                            collected.append(t)
                    text = "\n".join(collected)
            except Exception:
                pass
            # Append sources section for transparency
            if chunks:
                src_lines = ["\n\n#### Sources"]
                for ch in chunks[:8]:
                    src_lines.append(f"- [SOP:{ch['chunk_id']}] Section {ch.get('chunk_index','?')}")
                text = (text or "").strip() + "\n" + "\n".join(src_lines)
            return {"answer": text or "", "confidence": 0.9}
        except Exception as e:
            logger.error(f"Gemini freeform generation error: {e}")
            return await self._generate_template_freeform_response(query, chunks)

    async def _generate_ollama_freeform_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a comprehensive technical answer using Ollama (if selected)."""
        try:
            context = "\n\n".join([f"[Section {i+1}]\n{chunk['text']}\n(Chunk: {chunk['chunk_id']})" for i, chunk in enumerate(chunks)])
            prompt = (
                "You are a senior railway operations expert. Using ONLY the SOP Context below, write a comprehensive, technically detailed answer to the user's question. "
                "Include: purpose, conditions and thresholds, step-by-step actions, approvals/coordination, passenger/station comms, edge cases/exceptions, and post-actions. "
                "Use clear headings and bullet/numbered lists where appropriate. Cite relevant sections inline as [SOP:CHUNK_ID] when referencing specific rules. "
                "Avoid generic filler; be precise and grounded in the SOPs. If information is insufficient, state the limitation explicitly.\n\n"
                f"SOP Context:\n{context}\n\nUser Question: {query}\n\n"
                "Answer in well-formatted Markdown."
            )
            # Try python client, then HTTP chat endpoint
            answer_text = ""
            try:
                import ollama  # type: ignore
                response = ollama.chat(
                    model=getattr(settings, 'ollama_model', 'llama2'),
                    messages=[{'role': 'user', 'content': prompt}]
                )
                answer_text = response.get('message', {}).get('content', '')
            except Exception:
                url = getattr(settings, 'ollama_url', 'http://localhost:11434') + '/api/chat'
                payload = {
                    'model': getattr(settings, 'ollama_model', 'llama2'),
                    'messages': [{'role': 'user', 'content': prompt}]
                }
                r = requests.post(url, json=payload, timeout=60)
                r.raise_for_status()
                data = r.json()
                answer_text = data.get('message', {}).get('content') or data.get('response', '')
            # Append sources
            if chunks:
                src_lines = ["\n\n#### Sources"]
                for ch in chunks[:8]:
                    src_lines.append(f"- [SOP:{ch['chunk_id']}] Section {ch.get('chunk_index','?')}")
                answer_text = (answer_text or "").strip() + "\n" + "\n".join(src_lines)
            return {"answer": answer_text or "", "confidence": 0.8}
        except Exception as e:
            logger.error(f"Ollama freeform generation error: {e}")
            return await self._generate_template_freeform_response(query, chunks)

    async def _generate_template_freeform_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Freeform Markdown answer without external LLM, using SOP chunks."""
        if not chunks:
            return {"answer": "No relevant SOP content found.", "confidence": 0.0}
        # Build a richer narrative answer from top chunks
        lines: List[str] = []
        lines.append(f"**Query:** {query}")
        # Overview paragraph from top chunk
        top = chunks[0]
        overview = (top.get('text', '')[:700]).strip()
        if overview:
            lines.append("\n**Overview**\n" + overview)
        # Synthesize recommended actions as paragraphs
        bullets: List[str] = []
        import re
        for ch in chunks[:6]:
            for line in ch.get('text', '').splitlines():
                l = line.strip()
                if not l:
                    continue
                if l[:2].strip()[:1] in {'-', '•', '–', '—'} or l[:1].isdigit() or l.lower().startswith(('if ', 'in case')):
                    bullets.append(l.lstrip('-•–—0123456789.) ').strip())
        seen = set(); normd = []
        for b in bullets:
            k = b.lower().rstrip('. ')
            if k and k not in seen:
                seen.add(k); normd.append(b)
        if normd:
            lines.append("\n**Recommended Actions**")
            for s in self._normalize_steps(normd)[:12]:
                lines.append(f"- {s}")
        # Append sources
        lines.append("\n**Sources**")
        for ch in chunks[:8]:
            lines.append(f"- [SOP:{ch['chunk_id']}] Section {ch.get('chunk_index','?')}")
        return {"answer": "\n".join(lines), "confidence": 0.65}

    def _normalize_steps(self, steps: Optional[List[str]]) -> List[str]:
        """Normalize steps to imperative, concise, non-duplicated commands.
        Applies simple pattern rewrites and de-duplication.
        """
        if not steps:
            return []
        import re
        normd: List[str] = []
        seen = set()
        for s in steps:
            if not s:
                continue
            t = s.strip()
            # Drop leading labels like "Platform change procedure:"
            t = re.sub(r"^[A-Za-z ]+\s*:\s*", "", t)
            # Convert "In case of <condition>, <action>" -> "If <condition>, <action>."
            t = re.sub(r"(?i)^in\s+case\s+of\s+([^,]+),\s*(.+)$", r"If \1, \2", t)
            # Remove actor+modal prefixes -> imperative
            t = re.sub(r"(?i)^(?:operators?|train\s*crew|dispatchers?)\s+must\s+", "", t)
            t = re.sub(r"(?i)^(?:operators?|train\s*crew|dispatchers?)\s+should\s+", "", t)
            t = re.sub(r"(?i)^must\s+", "", t)
            # Convert policy statements like "Trains may <action> if <condition>" to imperative
            m_may_if = re.match(r"(?i)^(?:the\s+)?train[s]?\s+may\s+(.+?)\s+if\s+(.+?)\.?$", t)
            if m_may_if:
                action = m_may_if.group(1).strip().rstrip('.')
                cond = m_may_if.group(2).strip().rstrip('.')
                # Remove leading articles/pronouns from action
                action = re.sub(r"^(?:the\s+|a\s+|an\s+)", "", action, flags=re.IGNORECASE)
                t = f"If {cond}, {action}."
            else:
                # Generic "Trains may <action>" -> imperative action
                m_may = re.match(r"(?i)^(?:the\s+)?train[s]?\s+may\s+(.+?)\.?$", t)
                if m_may:
                    action2 = m_may.group(1).strip().rstrip('.')
                    action2 = re.sub(r"^(?:the\s+|a\s+|an\s+)", "", action2, flags=re.IGNORECASE)
                    t = f"{action2[0].upper() + action2[1:]}." if action2 else t
            # Priority patterns: "X have priority over Y" -> "Prioritize X over Y"
            m = re.search(r"(.+?)\s+have priority over\s+(.+?)(\.|$)", t, flags=re.IGNORECASE)
            if m:
                left = m.group(1).strip().rstrip('.')
                right = m.group(2).strip().rstrip('.')
                t = f"Prioritize {left} over {right}."
            # "Priority should be given to X over Y" -> "Prioritize X over Y"
            m2 = re.search(r"(?i)priority\s+should\s+be\s+given\s+to\s+(.+?)\s+over\s+(.+?)(\.|$)", t)
            if m2:
                left = m2.group(1).strip().rstrip('.')
                right = m2.group(2).strip().rstrip('.')
                t = f"Prioritize {left} over {right}."
            # "should be given priority to X over Y" -> "Prioritize X over Y"
            m3 = re.search(r"(?i)should\s+be\s+given\s+priority\s+to\s+(.+?)\s+over\s+(.+?)(\.|$)", t)
            if m3:
                left = m3.group(1).strip().rstrip('.')
                right = m3.group(2).strip().rstrip('.')
                t = f"Prioritize {left} over {right}."
            # "Emergency services always have highest priority" -> imperative
            t = re.sub(r"(?i)^(.*?)(emergency services) always have highest priority.*", r"Assign highest priority to \2.", t)
            # Approval: "must be approved by X" -> "Obtain X approval"
            t = re.sub(r"(?i).*must be approved by\s+the\s+control\s+center.*", "Obtain control center approval.", t)
            t = re.sub(r"(?i).*must be approved by\s+control\s+center.*", "Obtain control center approval.", t)
            t = re.sub(r"(?i).*must be approved by\s+([A-Za-z ]+).*", lambda m2: f"Obtain {m2.group(1).strip()} approval.", t)
            # Trim excessive length
            t = t[:220].strip()
            # Ensure sentence-style capitalization
            if t and not t[0].isupper():
                t = t[0].upper() + t[1:]
            key = t.lower().rstrip('. ')
            if key and key not in seen:
                seen.add(key)
                normd.append(t)
        return normd
    
    async def _generate_ollama_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate structured response using Ollama (JSON instruct + parse)."""
        try:
            # Prepare context from chunks
            context = "\n\n".join([f"[Section {i+1}]\n{chunk['text']}\n(Chunk: {chunk['chunk_id']})" for i, chunk in enumerate(chunks)])

            # Create JSON-structured prompt similar to Gemini path
            prompt = (
                "You are a railway operations expert. Use ONLY the provided SOP context to answer the user's question. "
                "Reply strictly as minified JSON with no extra commentary, no code fences. "
                "Schema: {\n  \"title\": string,\n  \"summary\": string,\n  \"steps\": [string],\n  \"cautions\": [string],\n  \"citations\": [{\"chunk_id\": string, \"section\": integer, \"excerpt\": string}]\n}\n"
                "Constraints: summary must be 1-2 sentences; provide 3-6 concise steps (<=24 words each); 1-3 cautions (<=20 words each). "
                "Write steps as imperative operational actions; never repeat SOP sentences verbatim. "
                "Convert policy statements like 'Trains may <action> if <condition>' into 'If <condition>, <action>'. "
                "Focus strictly on answering the user question; ignore unrelated procedures not asked in the question. "
                "Do not invent information beyond the SOP context; if insufficient, set steps=[] and include a caution.\n\n"
                f"SOP Context:\n{context}\n\nUser Question: {query}\n\n"
                "Return JSON only."
            )

            # Call Ollama
            answer_text = ""
            try:
                import ollama  # type: ignore
                response = ollama.chat(
                    model=getattr(settings, 'ollama_model', 'llama2'),
                    messages=[
                        {'role': 'system', 'content': 'You are a helpful railway operations assistant.'},
                        {'role': 'user', 'content': prompt},
                    ]
                )
                answer_text = response.get('message', {}).get('content', '')
            except Exception:
                # Fallback to HTTP endpoint
                url = getattr(settings, 'ollama_url', 'http://localhost:11434') + '/api/chat'
                payload = {
                    'model': getattr(settings, 'ollama_model', 'llama2'),
                    'messages': [
                        {'role': 'system', 'content': 'You are a helpful railway operations assistant.'},
                        {'role': 'user', 'content': prompt},
                    ]
                }
                resp = requests.post(url, json=payload, timeout=60)
                resp.raise_for_status()
                data = resp.json()
                answer_text = data.get('message', {}).get('content') or data.get('response', '')

            # Parse structured JSON (robust)
            structured = None
            if answer_text:
                try:
                    structured = json.loads(answer_text)
                except Exception:
                    try:
                        import re
                        m = re.search(r"\{[\s\S]*\}", answer_text)
                        if m:
                            structured = json.loads(m.group(0))
                    except Exception:
                        structured = None

            if not structured:
                # Fallback to template-structured response
                return await self._generate_template_response(query, chunks)

            # Normalize/de-duplicate steps then build markdown answer
            md_lines = []
            if structured.get('title'):
                md_lines.append(f"### {structured['title']}")
            if structured.get('summary'):
                md_lines.append(structured['summary'])
            if structured.get('steps'):
                structured['steps'] = self._normalize_steps(structured['steps'])
                md_lines.append("\nSteps:")
                for i, s in enumerate(structured['steps'], 1):
                    md_lines.append(f"{i}. {s}")
            if structured.get('cautions'):
                md_lines.append("\nCautions:")
                for c in structured['cautions']:
                    md_lines.append(f"- {c}")
            answer_md = "\n".join(md_lines)

            return {"answer": answer_md, "structured": structured, "confidence": 0.8}

        except Exception as e:
            logger.error(f"Ollama response generation error: {e}")
            return await self._generate_template_response(query, chunks)

    async def _generate_gemini_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate response using Google Gemini via REST API (no extra deps)."""
        try:
            if not self.gemini_api_key:
                raise RuntimeError("Gemini API key not configured")

            context = "\n\n".join([f"[Section {i+1}]\n{chunk['text']}\n(Chunk: {chunk['chunk_id']})" for i, chunk in enumerate(chunks)])
            # Extract bullet-like points to guide concise, non-redundant steps
            points: List[str] = []
            try:
                seen = set()
                for ch in chunks:
                    for raw in ch.get('text', '').splitlines():
                        line = raw.strip()
                        if not line:
                            continue
                        if line[:2].strip()[:1] in {'-', '•', '–', '—'} or line[:1].isdigit():
                            norm = line.lstrip('-•–—0123456789.) ').strip().lower()
                            if 3 <= len(norm) <= 220 and norm not in seen:
                                seen.add(norm)
                                points.append(line.lstrip('-•–— ').strip())
                        elif 8 <= len(line) <= 160 and line.endswith('.'):
                            norm = line.lower()
                            if norm not in seen:
                                seen.add(norm)
                                points.append(line)
                points = points[:15]
            except Exception:
                points = []
            prompt = (
                "You are a railway operations expert. Use ONLY the provided SOP context to answer the user's question. "
                "Reply strictly as minified JSON with no extra commentary, no code fences. "
                "Schema: {\n  \"title\": string,\n  \"summary\": string,\n  \"steps\": [string],\n  \"cautions\": [string],\n  \"citations\": [{\"chunk_id\": string, \"section\": integer, \"excerpt\": string}]\n}\n"
                "Constraints: summary must be 1-2 sentences; provide 3-6 concise steps (<=24 words each); 1-3 cautions (<=20 words each). "
                "Write steps as imperative operational actions (e.g., 'Assess congestion status', 'Obtain control center approval', 'Notify passengers via PA/boards', 'Route to alternate platform', 'Update signage', 'Coordinate station staff'). "
                "Never repeat SOP sentences verbatim; convert policy statements like 'Trains may <action> if <condition>' into 'If <condition>, <action>'. "
                "When SOP Points are provided, derive and consolidate steps from those points; do not repeat a point verbatim; do not use the exact sentence as a step; merge duplicates. "
                "Do not invent information beyond the SOP context; if insufficient, set steps=[] and include a caution.\n\n"
                f"SOP Context:\n{context}\n\n"
                + ("SOP Points:\n- " + "\n- ".join(points) + "\n\n" if points else "")
                + f"User Question: {query}\n\n"
                "Return JSON only."
            )

            body = {
                "contents": [
                    {"parts": [{"text": prompt}]}
                ]
            }
            # Try multiple models and API versions for compatibility across accounts
            urls = []
            for model in self._gemini_model_candidates():
                urls.append(f"https://generativelanguage.googleapis.com/v1/models/{model}:generateContent?key={self.gemini_api_key}")
                urls.append(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={self.gemini_api_key}")
            last_err = None
            data = None
            for u in urls:
                try:
                    resp = requests.post(u, json=body, timeout=30)
                    resp.raise_for_status()
                    data = resp.json()
                    break
                except Exception as e:
                    last_err = e
                    continue
            if data is None and last_err is not None:
                raise last_err
            # Extract first candidate text
            text = ""
            try:
                candidates = data.get('candidates', [])
                if candidates:
                    parts = candidates[0].get('content', {}).get('parts', [])
                    if parts:
                        text = parts[0].get('text', '')
            except Exception:
                pass
            structured: Optional[Dict[str, Any]] = None
            if text:
                # Try direct JSON parse, else extract first JSON object substring
                try:
                    structured = json.loads(text)
                except Exception:
                    try:
                        import re
                        m = re.search(r"\{[\s\S]*\}", text)
                        if m:
                            structured = json.loads(m.group(0))
                        else:
                            structured = None
                    except Exception:
                        structured = None
            if not structured:
                # Fallback structured minimal from top chunk
                top = chunks[0]
                structured = {
                    "title": "SOP Guidance",
                    "summary": top['text'][:300],
                    "steps": [],
                    "cautions": ["Could not parse structured answer; showing excerpt."],
                    "citations": [{"chunk_id": top['chunk_id'], "section": 1, "excerpt": top['text'][:160]}]
                }

            # Normalize and de-duplicate steps to avoid repeated lines
            if structured.get('steps'):
                seen_steps = set()
                unique_steps = []
                for s in structured['steps']:
                    key = (s or '').strip().lower()
                    if key and key not in seen_steps:
                        seen_steps.add(key)
                        unique_steps.append(s)
                structured['steps'] = unique_steps

            # Normalize and de-duplicate steps to avoid repeated lines
            if structured.get('steps'):
                structured['steps'] = self._normalize_steps(structured['steps'])

            # Render a markdown answer from structured fields (not overly short)
            md_lines = []
            if structured.get('title'): md_lines.append(f"### {structured['title']}")
            if structured.get('summary'): md_lines.append(structured['summary'])
            if structured.get('steps'):
                md_lines.append("\nSteps:")
                for i, s in enumerate(structured['steps'], 1):
                    md_lines.append(f"{i}. {s}")
            if structured.get('cautions'):
                md_lines.append("\nCautions:")
                for c in structured['cautions']:
                    md_lines.append(f"- {c}")
            answer_text = "\n".join(md_lines) or structured.get('summary') or ""

            return {"answer": answer_text, "structured": structured, "confidence": 0.88}
        except Exception as e:
            logger.error(f"Gemini response generation error: {e}")
            return await self._generate_template_response(query, chunks)
    
    async def _generate_template_response(self, query: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Structured response fallback without external LLMs."""
        if not chunks:
            return {"answer": "No relevant SOP content found.", "confidence": 0.0}

        # Heuristic: use top chunk; parse lines into steps if they look like bullets or numbered
        top = chunks[0]
        text = top['text']
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        steps = [l.lstrip('-•–—0123456789. ')[:200].strip() for l in lines if (l[:2].strip()[:1] in {'-', '•', '–', '—'} or l[:1].isdigit())]
        # If no bullet-like lines, synthesize steps from sentences
        if not steps:
            import re
            sentences = re.split(r"(?<=[.!?])\s+", text)
            steps = [s.strip()[:200] for s in sentences if len(s.strip()) > 0][:8]
        structured = {
            "title": "SOP Guidance",
            "summary": lines[0] if lines else text[:300],
            "steps": self._normalize_steps(steps[:8]),
            "cautions": [],
            "citations": [{"chunk_id": top['chunk_id'], "section": 1, "excerpt": text[:160]}]
        }
        # Build markdown answer
        md = [f"### {structured['title']}", structured['summary']]
        if structured['steps']:
            md.append("\nSteps:")
            md.extend([f"{i+1}. {s}" for i, s in enumerate(structured['steps'])])
        answer = "\n".join(md)
        return {"answer": answer, "structured": structured, "confidence": 0.72}
    
    def _cosine_similarity(self, a, b):
        """Calculate cosine similarity between two vectors"""
        import numpy as np
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    
    async def get_query_history(self, limit: int, db: Session) -> List[Dict[str, Any]]:
        """Get recent query history"""
        try:
            queries = db.query(QueryLog).order_by(QueryLog.created_at.desc()).limit(limit).all()
            
            return [
                {
                    "id": str(query.id),
                    "query_text": query.query_text,
                    "response_text": query.response_text,
                    "cited_chunks": query.cited_chunks,
                    "created_at": query.created_at.isoformat()
                }
                for query in queries
            ]
            
        except Exception as e:
            logger.error(f"Get query history error: {e}")
            return []