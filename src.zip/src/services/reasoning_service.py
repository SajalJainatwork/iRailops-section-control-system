# Reasoning Service - delay analysis and recovery recommendations

import logging
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime, timedelta
import uuid

from ..data.models import TrainEvent, Recommendation, DelayAnalysis, Block, Station
from ..ml.delay_classifier import DelayClassifier
from ..utils.rule_engine import RuleEngine

logger = logging.getLogger(__name__)

class ReasoningService:
    """Service for delay analysis and recovery recommendations"""
    
    def __init__(self):
        self.delay_classifier = DelayClassifier()
        self.rule_engine = RuleEngine()
    
    async def analyze_delay(self, event_id: str, db: Session) -> Dict[str, Any]:
        """Analyze delay and generate recommendations"""
        try:
            # Get the event
            event = db.query(TrainEvent).filter(TrainEvent.event_id == event_id).first()
            if not event:
                raise ValueError(f"Event {event_id} not found")
            
            # Analyze delay cause
            delay_analysis = await self._analyze_delay_cause(event, db)
            
            # Generate recovery recommendations
            recommendations = await self._generate_recommendations(event, delay_analysis, db)
            
            # Store recommendations
            for rec in recommendations:
                recommendation = Recommendation(
                    train_no=event.train_no,
                    move_type=rec['move_type'],
                    score=rec['score'],
                    explanation=rec['explanation'],
                    sop_refs=rec.get('sop_refs', [])
                )
                db.add(recommendation)
            
            db.commit()
            
            return {
                "event_id": event_id,
                "train_no": event.train_no,
                "delay_analysis": delay_analysis,
                "recommendations": recommendations
            }
            
        except Exception as e:
            db.rollback()
            logger.error(f"Delay analysis error: {e}")
            raise
    
    async def get_recommendations(self, train_no: str, limit: int, db: Session) -> List[Dict[str, Any]]:
        """Get recommendations for a specific train"""
        try:
            recommendations = db.query(Recommendation).filter(
                Recommendation.train_no == train_no
            ).order_by(desc(Recommendation.score)).limit(limit).all()
            
            return [
                {
                    "id": str(rec.id),
                    "train_no": rec.train_no,
                    "move_type": rec.move_type,
                    "score": rec.score,
                    "explanation": rec.explanation,
                    "sop_refs": rec.sop_refs,
                    "status": rec.status,
                    "created_at": rec.created_at.isoformat()
                }
                for rec in recommendations
            ]
            
        except Exception as e:
            logger.error(f"Get recommendations error: {e}")
            raise
    
    async def _analyze_delay_cause(self, event: TrainEvent, db: Session) -> Dict[str, Any]:
        """Analyze the cause of delay"""
        # Get context for analysis
        context = await self._get_delay_context(event, db)
        
        # Use rule-based analysis for MVP
        cause_analysis = self.rule_engine.analyze_delay_cause(context)
        
        return {
            "delay_minutes": event.delay_minutes,
            "likely_cause": cause_analysis['cause'],
            "confidence": cause_analysis['confidence'],
            "factors": cause_analysis['factors']
        }
    
    async def _generate_recommendations(self, event: TrainEvent, delay_analysis: Dict[str, Any], db: Session) -> List[Dict[str, Any]]:
        """Generate recovery recommendations"""
        recommendations = []
        
        # Get network context
        network_context = await self._get_network_context(event, db)
        
        # Apply recovery rules
        recovery_moves = self.rule_engine.generate_recovery_moves(
            event, delay_analysis, network_context
        )
        
        for move in recovery_moves:
            recommendations.append({
                "move_type": move['type'],
                "score": move['score'],
                "explanation": move['explanation'],
                "sop_refs": move.get('sop_refs', [])
            })
        
        return recommendations
    
    async def _get_delay_context(self, event: TrainEvent, db: Session) -> Dict[str, Any]:
        """Get context for delay analysis"""
        # Get recent events for the same train
        recent_events = db.query(TrainEvent).filter(
            TrainEvent.train_no == event.train_no,
            TrainEvent.created_at <= event.created_at
        ).order_by(desc(TrainEvent.created_at)).limit(10).all()
        
        # Get events at the same station around the same time
        station_events = db.query(TrainEvent).filter(
            TrainEvent.station_code == event.station_code,
            TrainEvent.created_at.between(
                event.created_at - timedelta(hours=1),
                event.created_at + timedelta(hours=1)
            )
        ).all()
        
        return {
            "event": event,
            "recent_events": recent_events,
            "station_events": station_events,
            "delay_minutes": event.delay_minutes
        }
    
    async def _get_network_context(self, event: TrainEvent, db: Session) -> Dict[str, Any]:
        """Get network context for recommendations"""
        # Get station information
        station = db.query(Station).filter(Station.code == event.station_code).first()
        
        # Get connected blocks
        blocks = db.query(Block).filter(
            (Block.from_station == event.station_code) | 
            (Block.to_station == event.station_code)
        ).all()
        
        # Get trains in nearby stations
        nearby_stations = [b.from_station if b.to_station == event.station_code else b.to_station for b in blocks]
        nearby_events = db.query(TrainEvent).filter(
            TrainEvent.station_code.in_(nearby_stations),
            TrainEvent.created_at >= event.created_at - timedelta(minutes=30)
        ).all()
        
        return {
            "station": station,
            "blocks": blocks,
            "nearby_events": nearby_events,
            "network_congestion": len(nearby_events)
        }
