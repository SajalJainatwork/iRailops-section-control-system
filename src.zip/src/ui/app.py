# Streamlit UI for Railway Operations System

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import requests
import os
try:
    # Prefer absolute import to avoid relative import issues when running via streamlit
    from src.config import settings as app_settings
except Exception:
    app_settings = None
import json
from typing import Dict, List, Any

def _probe_health(base_url: str, timeout: float = 0.7) -> bool:
    try:
        r = requests.get(f"{base_url}/health", timeout=timeout)
        return r.status_code == 200
    except Exception:
        return False

def _dedupe(seq: List[str]) -> List[str]:
    seen = set()
    out: List[str] = []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out

def _detect_api_base_url() -> tuple[str, str, bool]:
    """
    Determine the API base URL with this priority:
    1) API_BASE_URL env var (no probing)
    2) src.config settings (probe)
    3) Fallbacks: http://localhost:8010 then http://localhost:8000 (probe)

    Returns: (api_base_url, source, reachable)
    source in {"env", "settings", "fallback"}
    """
    # 1) Env override wins
    env_url = os.getenv("API_BASE_URL")
    if env_url:
        return env_url, "env", _probe_health(env_url)

    # 2) Settings-derived + probe
    candidates: List[str] = []
    source = "settings"
    if app_settings is not None:
        host = "localhost" if app_settings.api_host in {"0.0.0.0", "127.0.0.1"} else app_settings.api_host
        settings_url = f"http://{host}:{app_settings.api_port}"
        # Try 8010 first if settings points to 8000 (common dev)
        if str(app_settings.api_port) == "8000":
            candidates.append(f"http://{host}:8010")
        candidates.append(settings_url)
    else:
        source = "fallback"

    # 3) Generic fallbacks
    candidates.extend([
        "http://localhost:8010",
        "http://localhost:8000",
    ])
    candidates = _dedupe(candidates)

    for url in candidates:
        if _probe_health(url):
            # If it matches the settings-derived URL, mark as settings; else fallback
            src = "settings" if ('settings_url' in locals() and url == settings_url) else "fallback"
            return url, src, True

    # None reachable: pick the first (best guess) and mark unreachable
    chosen = candidates[0] if candidates else "http://localhost:8000"
    return chosen, source if source else "fallback", False

# Configure page
st.set_page_config(
    page_title="Railway Operations System",
    page_icon="🚂",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Detect API base URL once at startup
API_BASE_URL, _API_SOURCE, _API_REACHABLE = _detect_api_base_url()

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .recommendation-card {
        background-color: #f9fafb; /* subtle gray for contrast in both themes */
        color: #0f172a; /* force dark text for readability */
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #e5e7eb;
        margin-bottom: 1rem;
    }
    .recommendation-card h4, .recommendation-card p {
        color: #0f172a;
        margin: 0.25rem 0;
    }
</style>
""", unsafe_allow_html=True)

def main():
    """Main application"""
    st.markdown('<h1 class="main-header">🚂 Railway Operations System</h1>', unsafe_allow_html=True)
    # Show which API the UI is using (helps diagnose 0,0 dashboard)
    caption = f"API: {API_BASE_URL} ({_API_SOURCE}{'' if _API_REACHABLE else ', unreachable'})"
    st.caption(caption)
    
    # Sidebar
    with st.sidebar:
        st.header("Navigation")
        page = st.selectbox(
            "Select Page",
            ["Delay Dashboard", "Recovery Recommendations", "Ops Copilot Q&A"]
        )
        
        st.header("Quick Actions")
        if st.button("Refresh Data"):
            st.rerun()
    
    # Main content based on selected page
    if page == "Delay Dashboard":
        show_delay_dashboard()
    elif page == "Recovery Recommendations":
        show_recovery_recommendations()
    elif page == "Ops Copilot Q&A":
        show_ops_copilot()
    
    # No uploads from UI; backend handles data ingestion/simulation

def show_delay_dashboard():
    """Delay Dashboard tab"""
    st.header("📊 Delay Dashboard")
    
    # Get summary metrics from API
    summary = None
    try:
        resp = requests.get(f"{API_BASE_URL}/api/metrics/summary", timeout=10)
        if resp.status_code == 200:
            summary = resp.json()
    except Exception as e:
        st.caption(f"Metrics summary unavailable: {e}")

    # Get delayed trains (events)
    try:
        response = requests.get(f"{API_BASE_URL}/api/events/delayed")
        if response.status_code == 200:
            delayed_trains = response.json().get('trains', [])
        else:
            delayed_trains = []
    except Exception as e:
        st.warning(f"Could not reach API at {API_BASE_URL} (using fallback). Error: {e}")
        delayed_trains = []
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_delayed = summary.get('delayed_trains') if summary else len({t['train_no'] for t in delayed_trains})
        st.metric("Total Delayed Trains", int(total_delayed or 0))
    
    with col2:
        avg_delay = summary.get('avg_delay_minutes') if summary else (
            sum(train['delay_minutes'] for train in delayed_trains) / len(delayed_trains) if delayed_trains else 0
        )
        st.metric("Average Delay", f"{float(avg_delay):.1f} min")
    
    with col3:
        severe_delays = summary.get('severe_trains') if summary else len({t['train_no'] for t in delayed_trains if t['delay_minutes'] > 30})
        st.metric("Severe Delays (>30min)", int(severe_delays or 0))
    
    with col4:
        total_trains = summary.get('total_trains') if summary else None
        if total_trains and total_trains > 0:
            on_time_trains = total_trains - int(total_delayed or 0)
            st.metric("On-Time Performance", f"{(on_time_trains/total_trains)*100:.1f}%")
        else:
            st.metric("On-Time Performance", "—")
    
    # Charts (use latest event per train to keep counts consistent with metrics)
    if delayed_trains:
        df_delays = pd.DataFrame(delayed_trains)
        # Ensure numeric delays for plotting
        if 'delay_minutes' in df_delays.columns:
            df_delays['delay_minutes'] = pd.to_numeric(df_delays['delay_minutes'], errors='coerce').fillna(0)
        # Ensure created_at is datetime for proper sorting
        if 'created_at' in df_delays.columns:
            df_delays['created_at'] = pd.to_datetime(df_delays['created_at'], errors='coerce')
        # Keep only the latest event per train (fallback to max delay if timestamps missing)
        if 'created_at' in df_delays.columns and df_delays['created_at'].notna().any():
            df_latest = df_delays.sort_values('created_at').drop_duplicates(subset='train_no', keep='last')
        else:
            df_latest = df_delays.sort_values('delay_minutes').drop_duplicates(subset='train_no', keep='last')
        col1, col2 = st.columns(2)
        
        with col1:
            # Delay distribution chart
            if not df_latest.empty:
                fig_delay_dist = px.histogram(
                    df_latest,
                    x='delay_minutes',
                    nbins=15,
                    title="Delay Distribution",
                    labels={'delay_minutes': 'Delay (minutes)', 'count': 'Number of Trains'}
                )
                st.plotly_chart(fig_delay_dist, width='stretch')
            else:
                st.info("No delayed trains to plot.")
        
        with col2:
            # Station delays chart
            station_delays = df_latest.groupby('station_code', dropna=True)['delay_minutes'].sum().reset_index()
            fig_station = px.bar(
                station_delays,
                x='station_code',
                y='delay_minutes',
                title="Delays by Station"
            )
            st.plotly_chart(fig_station, width='stretch')
        
        # Detailed table
        st.subheader("Delayed Trains Details")
        st.caption("Showing latest delayed event per train")
        st.dataframe(df_latest.sort_values(['delay_minutes','train_no'], ascending=[False, True]), width='stretch')
    else:
        st.info("No delayed trains found. All trains are running on time! 🎉")

def show_recovery_recommendations():
    """Recovery Recommendations tab"""
    st.header("🎯 Recovery Recommendations")
    
    # Train selection
    train_no = st.selectbox(
        "Select Train",
        ["12345", "67890", "11111", "22222"]  # Sample train numbers
    )
    
    if st.button("Get Recommendations"):
        try:
            response = requests.get(f"{API_BASE_URL}/api/recommendations/{train_no}")
            if response.status_code == 200:
                recommendations = response.json().get('recommendations', [])
                
                if recommendations:
                    for i, rec in enumerate(recommendations):
                        with st.container():
                            st.markdown(f"""
                            <div class="recommendation-card">
                                <h4>Recommendation {i+1}: {rec['move_type'].replace('_', ' ').title()}</h4>
                                <p><strong>Score:</strong> {rec['score']:.2f}</p>
                                <p><strong>Explanation:</strong> {rec['explanation']}</p>
                                <p><strong>Status:</strong> {rec['status']}</p>
                            </div>
                            """, unsafe_allow_html=True)

                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button(f"Apply", key=f"apply_{i}"):
                                    st.success("Recommendation applied!")
                            with col2:
                                if st.button(f"Reject", key=f"reject_{i}"):
                                    st.warning("Recommendation rejected!")
                else:
                    st.info("No recommendations available for this train.")
            else:
                st.error("Failed to fetch recommendations.")
        except:
            st.error("Unable to connect to the API. Please check if the backend is running.")
    
    # Manual recommendation input
    st.subheader("Manual Recommendation")
    with st.form("manual_recommendation"):
        move_type = st.selectbox("Move Type", ["skip_halt", "overtake", "prioritize", "platform_change"])
        explanation = st.text_area("Explanation")
        score = st.slider("Score", 0.0, 1.0, 0.5)
        
        if st.form_submit_button("Add Recommendation"):
            st.success("Manual recommendation added!")

def show_ops_copilot():
    """Ops Copilot Q&A tab"""
    st.header("🤖 Ops Copilot Q&A")
    # Show LLM status to help diagnose short answers
    llm_status = None
    llm_probe = None
    try:
        r = requests.get(f"{API_BASE_URL}/api/debug/llm-status", timeout=3)
        if r.status_code == 200:
            llm_status = r.json()
        # Attempt a tiny probe to detect invalid keys (non-blocking if it fails fast)
        try:
            rp = requests.get(f"{API_BASE_URL}/api/debug/llm-probe", timeout=3)
            if rp.status_code == 200:
                llm_probe = rp.json()
        except Exception:
            llm_probe = None
    except Exception:
        llm_status = None
    
    # Prepare session state and handle prefill BEFORE creating the input widget
    if 'ops_query' not in st.session_state:
        st.session_state['ops_query'] = ""
    # If a suggestion set a prefill value, apply it before rendering the widget
    if st.session_state.get('ops_query_prefill'):
        st.session_state['ops_query'] = st.session_state.pop('ops_query_prefill')

    # Answer style
    style = st.radio("Answer style", ["Detailed", "Structured"], horizontal=True, index=0)
    mode = "detailed" if style == "Detailed" else "structured"
    if llm_status:
        client = llm_status.get("client_selected")
        gem_key = llm_status.get("gemini_key_present")
        g_model = llm_status.get("gemini_model")
        detail = [f"Backend client: {client}"]
        if client == "uninitialized":
            detail.append("(will initialize on first query)")
        if g_model:
            detail.append(f"Gemini model: {g_model}")
        warn = []
        if not gem_key:
            warn.append("Tip: Set GEMINI_API_KEY for richer Detailed answers.")
        if llm_probe and llm_probe.get("client_selected") == "gemini" and llm_probe.get("gemini_ok") is False:
            warn.append("Gemini key appears invalid or unreachable; Detailed answers may be brief.")
        st.caption(" | ".join(detail))
        if warn:
            st.warning(" ".join(warn))

    # Query input
    query = st.text_input("Ask a question about railway operations:", key="ops_query")
    
    if st.button("Ask Question") and query:
        try:
            response = requests.post(
                f"{API_BASE_URL}/api/rag/query",
                json={"query": query, "limit": (24 if mode=="detailed" else 12), "mode": mode}
            )
            
            if response.status_code == 200:
                result = response.json()
                # Prefer structured rendering if available
                structured = result.get('structured')
                if structured and mode == "structured":
                    if title := structured.get('title'):
                        st.subheader(title)
                    if summary := structured.get('summary'):
                        st.write(summary)
                    if steps := structured.get('steps'):
                        st.markdown("**Steps:**")
                        for i, s in enumerate(steps, 1):
                            st.write(f"{i}. {s}")
                    if cautions := structured.get('cautions'):
                        st.markdown("**Cautions:**")
                        for c in cautions:
                            st.write(f"- {c}")
                else:
                    st.subheader("Answer")
                    st.write(result.get('answer', ''))

                # Confidence / Model
                st.subheader("Confidence")
                st.progress(float(result.get('confidence', 0)))
                model_used = result.get('model_used')
                mode_used = result.get('mode')
                if model_used or mode_used:
                    st.caption(" | ".join([s for s in [f"Model: {model_used}" if model_used else None, f"Mode: {mode_used}" if mode_used else None] if s]))

                # Sources
                if result.get('cited_chunks'):
                    st.subheader("Source References")
                    for chunk in result['cited_chunks']:
                        title = f"SOP {chunk.get('doc_id','')} - Section {chunk.get('chunk_index','?')}"
                        with st.expander(title):
                            st.write(chunk.get('text',''))
            else:
                st.error("Failed to get answer from the system.")
        except:
            st.error("Unable to connect to the API. Please check if the backend is running.")
    
    # Sample questions
    st.subheader("Sample Questions")
    sample_questions = [
        "What should I do when a train is delayed by more than 30 minutes?",
        "How do I handle platform congestion?",
        "What is the procedure for skipping a halt?",
        "When can a train overtake another train?",
        "How do I prioritize trains during peak hours?"
    ]
    
    cols = st.columns(2)
    for i, question in enumerate(sample_questions):
        with cols[i % 2]:
            if st.button(question, key=f"sample_{i}"):
                # Set prefill for next render so we don't mutate after widget instantiation
                st.session_state["ops_query_prefill"] = question
                st.rerun()

    # Optional admin utility
    with st.expander("Admin: SOP utilities"):
        if st.button("Rescan SOPs from data/sops"):
            try:
                r = requests.post(f"{API_BASE_URL}/api/admin/ingest/sop-from-dir", timeout=30)
                if r.status_code == 200:
                    info = r.json()
                    st.success(f"Ingested: {len(info.get('ingested', []))}, Skipped: {len(info.get('skipped', []))}")
                else:
                    st.warning(f"Rescan failed: {r.status_code}")
            except Exception as e:
                st.error(f"Rescan error: {e}")

    # Uploads removed per requirement: all data handled in backend

if __name__ == "__main__":
    main()
