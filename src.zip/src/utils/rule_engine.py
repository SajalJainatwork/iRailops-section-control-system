# Rule Engine - business rules for delay analysis and recovery recommendations

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class RuleEngine:
    """Rule engine for delay analysis and recovery recommendations"""
    
    def __init__(self):
        self.delay_thresholds = {
            'minor': 5,
            'moderate': 15,
            'major': 30,
            'severe': 60
        }
    
    def analyze_delay_cause(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze delay cause using rule-based approach"""
        try:
            event = context.get('event')
            recent_events = context.get('recent_events', [])
            station_events = context.get('station_events', [])
            
            if not event:
                return {'cause': 'unknown', 'confidence': 0.0, 'factors': []}
            
            factors = []
            cause_scores = {}
            
            # Rule 1: Weather-related delays
            weather_score = self._check_weather_factors(event, recent_events)
            if weather_score > 0.5:
                cause_scores['weather'] = weather_score
                factors.append(f"Weather conditions affecting operations (score: {weather_score:.2f})")
            
            # Rule 2: Congestion-related delays
            congestion_score = self._check_congestion_factors(event, station_events)
            if congestion_score > 0.5:
                cause_scores['congestion'] = congestion_score
                factors.append(f"Station congestion detected (score: {congestion_score:.2f})")
            
            # Rule 3: Mechanical issues
            mechanical_score = self._check_mechanical_factors(event, recent_events)
            if mechanical_score > 0.5:
                cause_scores['mechanical'] = mechanical_score
                factors.append(f"Potential mechanical issues (score: {mechanical_score:.2f})")
            
            # Rule 4: Signal failures
            signal_score = self._check_signal_factors(event, station_events)
            if signal_score > 0.5:
                cause_scores['signal_failure'] = signal_score
                factors.append(f"Signal system issues detected (score: {signal_score:.2f})")
            
            # Rule 5: Passenger delays
            passenger_score = self._check_passenger_factors(event)
            if passenger_score > 0.5:
                cause_scores['passenger_delay'] = passenger_score
                factors.append(f"Passenger-related delays (score: {passenger_score:.2f})")
            
            # Determine most likely cause
            if cause_scores:
                most_likely_cause = max(cause_scores, key=cause_scores.get)
                confidence = cause_scores[most_likely_cause]
            else:
                most_likely_cause = 'other'
                confidence = 0.3
            
            return {
                'cause': most_likely_cause,
                'confidence': confidence,
                'factors': factors,
                'all_scores': cause_scores
            }
            
        except Exception as e:
            logger.error(f"Delay cause analysis error: {e}")
            return {'cause': 'unknown', 'confidence': 0.0, 'factors': []}
    
    def generate_recovery_moves(self, event, delay_analysis: Dict[str, Any], network_context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate recovery recommendations based on rules"""
        try:
            recommendations = []
            delay_minutes = event.delay_minutes
            cause = delay_analysis.get('cause', 'unknown')
            
            # Rule 1: Skip halt recommendation
            if self._can_skip_halt(event, network_context):
                recommendations.append({
                    'type': 'skip_halt',
                    'score': self._calculate_skip_score(delay_minutes, cause),
                    'explanation': f"Skip halt at {event.station_code} to recover {delay_minutes} minutes delay",
                    'sop_refs': ['skip_halt_procedure']
                })
            
            # Rule 2: Overtake recommendation
            if self._can_overtake(event, network_context):
                recommendations.append({
                    'type': 'overtake',
                    'score': self._calculate_overtake_score(delay_minutes, cause),
                    'explanation': f"Overtake slower train to recover delay",
                    'sop_refs': ['overtake_procedure']
                })
            
            # Rule 3: Priority recommendation
            if self._should_prioritize(event, delay_analysis):
                recommendations.append({
                    'type': 'prioritize',
                    'score': self._calculate_priority_score(delay_minutes, cause),
                    'explanation': f"Give priority to train {event.train_no} due to delay severity",
                    'sop_refs': ['priority_procedure']
                })
            
            # Rule 4: Platform change recommendation
            if self._can_change_platform(event, network_context):
                recommendations.append({
                    'type': 'platform_change',
                    'score': self._calculate_platform_score(delay_minutes, cause),
                    'explanation': f"Change platform to avoid congestion",
                    'sop_refs': ['platform_change_procedure']
                })
            
            # Sort by score
            recommendations.sort(key=lambda x: x['score'], reverse=True)
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Recovery move generation error: {e}")
            return []
    
    def _check_weather_factors(self, event, recent_events: List) -> float:
        """Check for weather-related factors"""
        # Simplified weather check - in real implementation, would check weather API
        hour = event.created_at.hour
        if hour in [6, 7, 8, 17, 18, 19]:  # Rush hours
            return 0.3
        return 0.1
    
    def _check_congestion_factors(self, event, station_events: List) -> float:
        """Check for congestion-related factors"""
        if len(station_events) > 5:
            return 0.8
        elif len(station_events) > 3:
            return 0.6
        return 0.2
    
    def _check_mechanical_factors(self, event, recent_events: List) -> float:
        """Check for mechanical factors"""
        if event.delay_minutes > 30:
            return 0.7
        elif event.delay_minutes > 15:
            return 0.4
        return 0.1
    
    def _check_signal_factors(self, event, station_events: List) -> float:
        """Check for signal-related factors"""
        # Check if multiple trains delayed at same station
        delayed_trains = [e for e in station_events if e.delay_minutes > 5]
        if len(delayed_trains) > 2:
            return 0.8
        return 0.2
    
    def _check_passenger_factors(self, event) -> float:
        """Check for passenger-related factors"""
        # Rush hour passenger delays
        hour = event.created_at.hour
        if hour in [7, 8, 17, 18]:
            return 0.6
        return 0.2
    
    def _can_skip_halt(self, event, network_context: Dict[str, Any]) -> bool:
        """Check if halt can be skipped"""
        station = network_context.get('station')
        if not station:
            return False
        
        # Check if station is not a junction or terminal
        if station.station_type in ['junction', 'terminal']:
            return False
        
        # Check if delay is significant enough
        return event.delay_minutes > 10
    
    def _can_overtake(self, event, network_context: Dict[str, Any]) -> bool:
        """Check if overtake is possible"""
        blocks = network_context.get('blocks', [])
        if not blocks:
            return False
        
        # Check if there are loop lines available
        loop_blocks = [b for b in blocks if b.block_type == 'loop']
        return len(loop_blocks) > 0 and event.delay_minutes > 15
    
    def _should_prioritize(self, event, delay_analysis: Dict[str, Any]) -> bool:
        """Check if train should be prioritized"""
        return event.delay_minutes > 20
    
    def _can_change_platform(self, event, network_context: Dict[str, Any]) -> bool:
        """Check if platform change is possible"""
        return event.delay_minutes > 5
    
    def _calculate_skip_score(self, delay_minutes: int, cause: str) -> float:
        """Calculate score for skip halt recommendation"""
        base_score = min(delay_minutes / 30.0, 1.0)
        if cause == 'congestion':
            return base_score * 0.9
        return base_score * 0.7
    
    def _calculate_overtake_score(self, delay_minutes: int, cause: str) -> float:
        """Calculate score for overtake recommendation"""
        base_score = min(delay_minutes / 20.0, 1.0)
        if cause == 'congestion':
            return base_score * 0.8
        return base_score * 0.6
    
    def _calculate_priority_score(self, delay_minutes: int, cause: str) -> float:
        """Calculate score for priority recommendation"""
        base_score = min(delay_minutes / 25.0, 1.0)
        if cause in ['mechanical', 'signal_failure']:
            return base_score * 0.9
        return base_score * 0.7
    
    def _calculate_platform_score(self, delay_minutes: int, cause: str) -> float:
        """Calculate score for platform change recommendation"""
        base_score = min(delay_minutes / 15.0, 1.0)
        if cause == 'congestion':
            return base_score * 0.8
        return base_score * 0.5
