# Track Visualizer (Standalone)

A standalone web page that renders a richer schematic railway network and shows only delayed trains as moving squares. Segments turn red when occupied and green when available. It simulates train movement, advancing each train to a neighboring segment roughly every 15–30 seconds. A manual Refresh pulls latest delayed trains from the API; the page also auto-syncs periodically.

- No changes to your existing project code
- Pure static HTML/JS/CSS (no build step)
- Pulls data from your running API (CORS is already enabled in the backend)

## What it shows
- Network: two parallel mainlines with connectors, a branch, and a few sidings (schematic, not geographic)
- Occupancy: segment is red if any delayed train is currently on it; otherwise green
- Trains: moving squares on segments
  - Orange = delayed
  - Red = very delayed
  - Each train continues onto adjacent segments; path choice is deterministic per train for consistency

## How to run

1) Ensure your API is running, for example:

```bash
# wsl.exe shell
python -m src.cli start-api
```

2) Serve this folder with a static server (browser blocks fetch from file://):

```bash
# Option A: Python
python -m http.server 9000

# Option B: Node (if you have npx)
npx serve . -l 9000
```

3) Open the page:
- http://localhost:9000/track-visualizer/index.html

4) Set API URL (top-left, defaults to http://localhost:8010) and click Save.
  - Trains will animate continuously (1s tick); data re-syncs about every 25s.
  - Click Refresh any time to force an immediate sync with the API.

## Notes
- This page uses only the `/api/events/delayed` endpoint to retrieve delayed trains. Positions are simulated along a synthetic network for visualization purposes.
- Schematic (not geographic). If a topology endpoint and true positions become available, the drawing and movement can be bound to real blocks/coordinates instead.
