(function(){
  const svg = document.getElementById('viz');
  const statusText = document.getElementById('statusText');
  const apiUrlInput = document.getElementById('apiUrl');
  const refreshBtn = document.getElementById('refreshBtn');
  const saveUrlBtn = document.getElementById('saveUrl');

  const LS_KEY = 'trackviz_api_url';
  // Default backend URL — change to 8000 to match project's uvicorn default
  const defaultUrl = 'http://localhost:8000';
  apiUrlInput.value = localStorage.getItem(LS_KEY) || defaultUrl;
  saveUrlBtn.addEventListener('click', ()=>{
    const url = apiUrlInput.value.trim();
    if(url){ localStorage.setItem(LS_KEY, url); }
  });

  const sim = {
    net: null,
    trains: new Map(), // id -> { segId, fromNode, toNode, progress, durationSec, lastUpdate, meta }
    segmentLocks: new Map(), // segId -> { dir: 'A>B', count: number }
  };
  const END_BEHAVIOR = 'bounce'; // 'bounce' or 'despawn'
  let movementTimer = null;
  let fetchTimer = null;

  refreshBtn.addEventListener('click', ()=>{ refreshData(true); });

  async function fetchDelayed() {
    const base = apiUrlInput.value.trim() || defaultUrl;
    const url = `${base.replace(/\/$/, '')}/api/events/delayed`;
    const resp = await fetch(url);
    if(!resp.ok) throw new Error(`fetch failed: ${resp.status}`);
    const data = await resp.json();
    return data.trains || data.events || [];
  }

  // Build a topology inspired by the last sketch: upper area with three parallel tracks and a branch to a coal mine; lower area with a main line and a quarry branch
  function buildNetwork(){
    const W = 1100, H = 400;
    const nodes = {
      UW:   { x: 80,  y: 140 },   // west upper main approach
      LW:   { x: 80,  y: 170 },   // west lower main approach
      UJ:   { x: 240, y: 150 },   // upper junction/throat
      U1L:  { x: 300, y: 110 }, U1R: { x: 950, y: 110 }, // top track
      U2L:  { x: 300, y: 140 }, U2R: { x: 950, y: 140 }, // middle track
      U3L:  { x: 300, y: 170 }, U3R: { x: 950, y: 170 }, // bottom track
      // Coal mine branch and stub
      CB1:  { x: 300, y: 80  }, CM:  { x: 380, y: 60  },
      U1S:  { x: 980, y: 95  }, // short headshunt/stub from U1R

      LMW:  { x: 120, y: 300 }, LM1: { x: 520, y: 300 }, LME: { x: 980, y: 300 },
      Q0:   { x: 60,  y: 340 }, Q1:  { x: 260, y: 320 }, QJ:  { x: 420, y: 300 }, // quarry branch joins near LM1
      LStub:{ x: 1000,y: 290 },
    };

    const segments = [
      // Upper throat from approaches to junction
      { id: 'UW-UJ', a: 'UW', b: 'UJ', type: 'branch' },
      { id: 'LW-UJ', a: 'LW', b: 'UJ', type: 'branch' },
      // Upper three parallel tracks to the right
      { id: 'U1L-U1R', a: 'U1L', b: 'U1R', type: 'main' },
      { id: 'U2L-U2R', a: 'U2L', b: 'U2R', type: 'main' },
      { id: 'U3L-U3R', a: 'U3L', b: 'U3R', type: 'main' },
      // Ladder from junction to three lines
      { id: 'UJ-U1L', a: 'UJ', b: 'U1L', type: 'branch' },
      { id: 'UJ-U2L', a: 'UJ', b: 'U2L', type: 'branch' },
      { id: 'UJ-U3L', a: 'UJ', b: 'U3L', type: 'branch' },
      // Coal mine branch and stub
      { id: 'UJ-CB1', a: 'UJ', b: 'CB1', type: 'branch' },
      { id: 'CB1-CM', a: 'CB1', b: 'CM',  type: 'siding' },
      { id: 'U1R-U1S', a: 'U1R', b: 'U1S', type: 'siding' },

      // Lower main and quarry branch
      { id: 'LMW-LM1', a: 'LMW', b: 'LM1', type: 'main' },
      { id: 'LM1-LME', a: 'LM1', b: 'LME', type: 'main' },
      { id: 'Q0-Q1',   a: 'Q0',  b: 'Q1',  type: 'branch' },
      { id: 'Q1-QJ',   a: 'Q1',  b: 'QJ',  type: 'branch' },
      { id: 'QJ-LM1',  a: 'QJ',  b: 'LM1', type: 'branch' },
      { id: 'LME-LStub', a: 'LME', b: 'LStub', type: 'siding' },
    ];

    const platforms = []; // not platform-focused in this scheme
    const labels = []; // remove labels per request

    const nodeToSegs = new Map();
    for(const seg of segments){
      if(!nodeToSegs.has(seg.a)) nodeToSegs.set(seg.a, []);
      if(!nodeToSegs.has(seg.b)) nodeToSegs.set(seg.b, []);
      nodeToSegs.get(seg.a).push(seg.id);
      nodeToSegs.get(seg.b).push(seg.id);
    }
    const segIdx = new Map(segments.map((s,i)=>[s.id,i]));
    const neighbors = new Map(); // segId -> Set of neighbor segIds
    for(const seg of segments){
      const set = new Set();
      for(const nid of [seg.a, seg.b]){
        const list = nodeToSegs.get(nid) || [];
        for(const sid of list){ if(sid !== seg.id) set.add(sid); }
      }
      neighbors.set(seg.id, set);
    }

    return { W, H, nodes, segments, neighbors, segIdx, platforms, labels };
  }

  function clearSvg(){ while(svg.firstChild) svg.removeChild(svg.firstChild); }

  function linePointBetween(nodes, aKey, bKey, t){
    const a = nodes[aKey], b = nodes[bKey];
    const x = a.x + (b.x - a.x) * t;
    const y = a.y + (b.y - a.y) * t;
    return { x, y };
  }

  function drawNetwork(net, occupancy){
    if(net.platforms){
      for(const p of net.platforms){
        const r = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        r.setAttribute('x', p.x); r.setAttribute('y', p.y);
        r.setAttribute('width', p.width); r.setAttribute('height', p.height);
        r.setAttribute('fill', '#d1d5db');
        r.setAttribute('opacity', '0.35');
        svg.appendChild(r);
      }
    }
    for(const seg of net.segments){
      const a = net.nodes[seg.a], b = net.nodes[seg.b];
      const el = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      el.setAttribute('x1', a.x); el.setAttribute('y1', a.y);
      el.setAttribute('x2', b.x); el.setAttribute('y2', b.y);
      const occ = occupancy.get(seg.id) || 0;
      const occCls = occ > 0 ? 'track-occupied' : 'track-available';
      const typeCls = seg.type === 'siding' ? 'track-siding' : (seg.type === 'branch' || seg.type === 'connector' ? 'track-branch' : '');
      el.setAttribute('class', `track-segment ${occCls} ${typeCls}`.trim());
      svg.appendChild(el);
    }
    for(const [id, p] of Object.entries(net.nodes)){
      const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      dot.setAttribute('cx', p.x); dot.setAttribute('cy', p.y);
      dot.setAttribute('r', 3.5); dot.setAttribute('fill', '#111827');
      svg.appendChild(dot);
    }
    if(net.labels){
      for(const l of net.labels){
        const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        t.setAttribute('x', l.x); t.setAttribute('y', l.y);
        t.setAttribute('fill', '#111827');
        t.setAttribute('font-size', '12');
        t.setAttribute('font-weight', '600');
        t.textContent = l.text;
        svg.appendChild(t);
      }
    }
  }

  function hashInt(str){
    let h = 0; const s = String(str||'');
    for(let i=0;i<s.length;i++){ h = ((h<<5)-h) + s.charCodeAt(i); h|=0; }
    return h|0;
  }
  function hashToSegment(segments, key){
    const pool = segments.filter(s => s.type !== 'connector');
    const h = Math.abs(hashInt(key));
    const idx = pool.length ? (h % pool.length) : 0;
    return pool[idx] || segments[0];
  }

  function randomDuration15to30(){ return 15 + Math.floor(Math.random()*16); }

  function dirString(fromNode, toNode){ return `${fromNode}>${toNode}`; }
  function enterSegmentLock(segId, fromNode, toNode){
    const lock = sim.segmentLocks.get(segId);
    const dir = dirString(fromNode, toNode);
    if(!lock){ sim.segmentLocks.set(segId, { dir, count: 1 }); return true; }
    if(lock.dir === dir){ lock.count += 1; return true; }
    return false; // conflicting direction
  }
  function leaveSegmentLock(segId){
    const lock = sim.segmentLocks.get(segId);
    if(!lock) return;
    lock.count -= 1;
    if(lock.count <= 0) sim.segmentLocks.delete(segId);
  }

  function initTrainState(net, id, t){
    const seg = hashToSegment(net.segments, t.station_code || t.train_no || id);
    const forward = (hashInt(id) & 1) === 0;
    const fromNode = forward ? seg.a : seg.b;
    const toNode   = forward ? seg.b : seg.a;
    const progress = Math.min(0.95, Math.max(0.05, ((t.delay_minutes||0) % 50)/50));
    const durationSec = randomDuration15to30();
    const severity = (t.status === 'very_delayed' || (t.severity && String(t.severity).includes('severe'))) ? 'severe' : 'delayed';
    const meta = { no: t.train_no || id, station: t.station_code || '', delay: t.delay_minutes || 0, severity };
    sim.trains.set(id, { id, segId: seg.id, fromNode, toNode, progress, durationSec, lastUpdate: performance.now(), meta });
    enterSegmentLock(seg.id, fromNode, toNode);
  }

  function updateTrainMeta(state, t){
    if(!state) return;
    const severity = (t.status === 'very_delayed' || (t.severity && String(t.severity).includes('severe'))) ? 'severe' : 'delayed';
    state.meta = { no: t.train_no || state.id, station: t.station_code || '', delay: t.delay_minutes || 0, severity };
  }

  function chooseNextSegment(net, currentSegId, atNode, prevSegId, trainId){
    const neighborIds = Array.from(net.neighbors.get(currentSegId) || []);
    const byNode = neighborIds.filter(sid => {
      const s = net.segments[net.segIdx.get(sid)];
      return s && (s.a === atNode || s.b === atNode);
    });
    if(byNode.length === 0) return null; // terminal node (no other segment from this node)
    const candidates = byNode.filter(sid => sid !== prevSegId);
    const pool = candidates.length ? candidates : byNode;
    if(pool.length === 0) return currentSegId; // dead-end: stay
    const h = Math.abs(hashInt(trainId + '|' + atNode));
    const idx = h % pool.length;
    return pool[idx];
  }

  function stepSimulation(){
    if(!sim.net) return;
    const now = performance.now();
    for(const state of sim.trains.values()){
      const dt = Math.max(0, (now - (state.lastUpdate||now)) / 1000);
      if(dt === 0) continue;
      state.lastUpdate = now;
      const speed = 1 / Math.max(1, state.durationSec || 20);
      state.progress += dt * speed;
      while(state.progress >= 1){
        state.progress -= 1;
        const prevSegId = state.segId;
        const atNode = state.toNode; // we've reached toNode
        // pick next segment
        const nextSegId = chooseNextSegment(sim.net, state.segId, atNode, prevSegId, state.id);
        if(nextSegId === null){
          // Terminal at atNode
          const curSeg = sim.net.segments[sim.net.segIdx.get(prevSegId)];
          if(!curSeg) break;
          if(END_BEHAVIOR === 'despawn'){
            // Release lock on the segment and remove train
            leaveSegmentLock(prevSegId);
            sim.trains.delete(state.id);
            break;
          }
          // bounce: reverse direction on same segment
          const other = (atNode === curSeg.a) ? curSeg.b : curSeg.a;
          // switch lock direction safely
          leaveSegmentLock(prevSegId);
          const canEnterRev = enterSegmentLock(prevSegId, atNode, other);
          if(!canEnterRev){ state.progress = 0.98; break; }
          state.segId = prevSegId;
          state.fromNode = atNode;
          state.toNode = other;
        } else {
          const nextSeg = sim.net.segments[sim.net.segIdx.get(nextSegId)];
          // Check directional lock on entering the next segment
          const intendedToNode = (nextSeg.a === atNode) ? nextSeg.b : nextSeg.a;
          const canEnter = enterSegmentLock(nextSeg.id, atNode, intendedToNode);
          if(!canEnter){
            // Blocked by opposing traffic: hold at end of current segment
            state.progress = 0.98;
            break;
          }
          // Leaving previous segment: release its lock
          leaveSegmentLock(prevSegId);
          state.segId = nextSeg.id;
          state.fromNode = atNode;
          state.toNode = intendedToNode;
        }
        state.durationSec = randomDuration15to30();
      }
    }
  }

  const MIN_GAP = 0.12; // 12% of a segment baseline
  const MIN_GAP_PIX = 12; // absolute pixel gap baseline for short segments
  function enforceGapsBothDirections(){
    const bySeg = new Map();
    for(const s of sim.trains.values()){
      if(!bySeg.has(s.segId)) bySeg.set(s.segId, []);
      bySeg.get(s.segId).push(s);
    }
    for(const [segId, arr] of bySeg.entries()){
      if(arr.length <= 1) continue;
      const seg = sim.net.segments[sim.net.segIdx.get(segId)];
      if(!seg) continue;
      const a = sim.net.nodes[seg.a], b = sim.net.nodes[seg.b];
      const len = Math.max(1, Math.hypot(b.x - a.x, b.y - a.y));
      const gap = Math.max(MIN_GAP, MIN_GAP_PIX / len); // dynamic gap
      // canonicalize progress from seg.a -> seg.b
      const canonical = arr.map(s=>({ s, p: (s.fromNode===seg.a && s.toNode===seg.b) ? s.progress : (1 - s.progress) }));
      canonical.sort((a,b)=>a.p-b.p);
      // Anchor to the front-most train and space backwards to maintain gap
      const n = canonical.length;
      canonical[n-1].p = Math.min(0.98, canonical[n-1].p);
      for(let i=n-2; i>=0; i--){
        const maxAllowed = Math.max(0.02, canonical[i+1].p - gap);
        canonical[i].p = Math.min(canonical[i].p, maxAllowed);
        if(i===0 && canonical[i].p < 0.02) canonical[i].p = 0.02; // floor
      }
      // write back
      for(const item of canonical){
        const s = item.s;
        if(s.fromNode===seg.a && s.toNode===seg.b){
          s.progress = item.p;
        } else {
          s.progress = 1 - item.p;
        }
      }
    }
  }

  function computeOccupancyFromState(){
    const occ = new Map();
    for(const s of sim.trains.values()){
      occ.set(s.segId, (occ.get(s.segId)||0)+1);
    }
    return occ;
  }

  function renderFromState(){
    if(!sim.net){ sim.net = buildNetwork(); }
    svg.setAttribute('width', sim.net.W);
    svg.setAttribute('height', sim.net.H);
    clearSvg();
    const occupancy = computeOccupancyFromState();
    drawNetwork(sim.net, occupancy);
    // Draw trains on top
    for(const s of sim.trains.values()){
      const pt = linePointBetween(sim.net.nodes, s.fromNode, s.toNode, Math.max(0, Math.min(1, s.progress)));
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', pt.x - 7); rect.setAttribute('y', pt.y - 7);
      rect.setAttribute('width', 14); rect.setAttribute('height', 14);
      rect.setAttribute('rx', 2); rect.setAttribute('ry', 2);
      const sevCls = s.meta?.severity === 'severe' ? 'train-severe' : 'train-delayed';
      rect.setAttribute('class', `train-rect ${sevCls}`);
      rect.setAttribute('title', `${s.meta?.no||s.id} • ${s.meta?.station||''} • ${s.meta?.delay||0}m`);
      svg.appendChild(rect);
    }
    statusText.textContent = `Trains: ${sim.trains.size} • Segments occupied: ${Array.from(occupancy.values()).filter(v=>v>0).length}`;
  }

  async function refreshData(isManual=false){
    try{
      statusText.textContent = isManual ? 'Refreshing…' : 'Syncing delayed trains…';
      if(!sim.net){ sim.net = buildNetwork(); }
      const arriving = await fetchDelayed();
      // Index by id
      const nextIds = new Set();
      for(const t of arriving){
        const id = String(t.train_no || t.id || `${t.station_code||''}-${t.departure_time||''}`);
        nextIds.add(id);
        if(!sim.trains.has(id)){
          initTrainState(sim.net, id, t);
        } else {
          updateTrainMeta(sim.trains.get(id), t);
        }
      }
      // Remove trains no longer delayed
      for(const id of Array.from(sim.trains.keys())){
        if(!nextIds.has(id)) sim.trains.delete(id);
      }
      renderFromState();
      statusText.textContent = `Synced ${arriving.length} delayed trains.`;
    } catch(err){
      statusText.textContent = `Error: ${err.message}`;
    }
  }

  function startLoops(){
    if(movementTimer){ clearInterval(movementTimer); movementTimer = null; }
    if(fetchTimer){ clearInterval(fetchTimer); fetchTimer = null; }
    // Movement: tick every second
    movementTimer = setInterval(()=>{ stepSimulation(); enforceGapsBothDirections(); renderFromState(); }, 1000);
    // Data refresh: every 20s to 30s
    fetchTimer = setInterval(()=>{ refreshData(false); }, 25000);
  }

  // Boot
  sim.net = buildNetwork();
  renderFromState();
  refreshData(true);
  startLoops();
})();
